import 'package:flutter/material.dart';
import '../services/quiz_service.dart';
import 'quiz_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  bool _loading = true;

  List<String> _niveaux = [];
  List<String> _categories = [];
  String? _niveauChoisi;
  String? _categorieChoisie;

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    final niveaux = await QuizService.niveaux();
    setState(() {
      _niveaux = niveaux;
      _niveauChoisi = niveaux.isNotEmpty ? niveaux.first : null;
      _loading = false;
    });
    _refreshCategories();
  }

  Future<void> _refreshCategories() async {
    final cats = await QuizService.categories(niveau: _niveauChoisi);
    setState(() {
      _categories = cats;
      _categorieChoisie = null;
    });
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }

    return Scaffold(
      appBar: AppBar(title: const Text('Quiz biblique')),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Text(
              'Choisissez un niveau',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 12),
            Wrap(
              spacing: 8,
              children: _niveaux.map((n) {
                final selected = n == _niveauChoisi;
                return ChoiceChip(
                  label: Text(n),
                  selected: selected,
                  onSelected: (_) {
                    setState(() => _niveauChoisi = n);
                    _refreshCategories();
                  },
                );
              }).toList(),
            ),
            const SizedBox(height: 24),
            const Text(
              'Catégorie (optionnel)',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 12),
            Expanded(
              child: ListView(
                children: [
                  RadioListTile<String?>(
                    title: const Text('Toutes les catégories'),
                    value: null,
                    groupValue: _categorieChoisie,
                    onChanged: (v) => setState(() => _categorieChoisie = v),
                  ),
                  ..._categories.map((c) => RadioListTile<String?>(
                        title: Text(c),
                        value: c,
                        groupValue: _categorieChoisie,
                        onChanged: (v) => setState(() => _categorieChoisie = v),
                      )),
                ],
              ),
            ),
            const SizedBox(height: 12),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                padding: const EdgeInsets.symmetric(vertical: 16),
              ),
              onPressed: _niveauChoisi == null
                  ? null
                  : () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => QuizScreen(
                            niveau: _niveauChoisi,
                            categorie: _categorieChoisie,
                          ),
                        ),
                      );
                    },
              child: const Text('Démarrer le quiz (10 questions)'),
            ),
          ],
        ),
      ),
    );
  }
}
