import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

/// Identité visuelle de l'app : un manuscrit ancien plutôt qu'une app
/// générique — fond parchemin, encre indigo, reflets dorés.
class AppColors {
  static const indigo = Color(0xFF1B2A4A); // encre profonde
  static const cream = Color(0xFFF7F1E3); // parchemin
  static const gold = Color(0xFFC9973F); // reflet doré
  static const sage = Color(0xFF6B7B58); // bonne réponse
  static const brick = Color(0xFFA8493B); // mauvaise réponse
  static const ink = Color(0xFF2B2B28); // texte principal
}

class AppTheme {
  static ThemeData get theme {
    final base = ThemeData(
      useMaterial3: true,
      colorScheme: ColorScheme.fromSeed(
        seedColor: AppColors.indigo,
        primary: AppColors.indigo,
        secondary: AppColors.gold,
        surface: AppColors.cream,
        error: AppColors.brick,
        brightness: Brightness.light,
      ),
      scaffoldBackgroundColor: AppColors.cream,
    );

    final displayFont = GoogleFonts.spectralTextTheme(base.textTheme);
    final bodyFont = GoogleFonts.sourceSans3TextTheme(base.textTheme);

    return base.copyWith(
      textTheme: bodyFont.copyWith(
        displayLarge: displayFont.displayLarge,
        displayMedium: displayFont.displayMedium,
        displaySmall: displayFont.displaySmall,
        headlineLarge: displayFont.headlineLarge?.copyWith(
          fontWeight: FontWeight.w700,
          color: AppColors.ink,
        ),
        headlineMedium: displayFont.headlineMedium?.copyWith(
          fontWeight: FontWeight.w700,
          color: AppColors.ink,
        ),
        titleLarge: displayFont.titleLarge?.copyWith(
          fontWeight: FontWeight.w600,
          color: AppColors.ink,
        ),
      ),
      appBarTheme: AppBarTheme(
        backgroundColor: AppColors.indigo,
        foregroundColor: AppColors.cream,
        elevation: 0,
        centerTitle: false,
        titleTextStyle: GoogleFonts.spectral(
          fontSize: 22,
          fontWeight: FontWeight.w600,
          color: AppColors.cream,
        ),
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: AppColors.indigo,
          foregroundColor: AppColors.cream,
          disabledBackgroundColor: AppColors.indigo.withOpacity(0.35),
          padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 20),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
          textStyle: GoogleFonts.sourceSans3(
            fontSize: 16,
            fontWeight: FontWeight.w600,
          ),
        ),
      ),
      segmentedButtonTheme: SegmentedButtonThemeData(
        style: SegmentedButton.styleFrom(
          selectedBackgroundColor: AppColors.gold,
          selectedForegroundColor: AppColors.ink,
          foregroundColor: AppColors.indigo,
        ),
      ),
      chipTheme: base.chipTheme.copyWith(
        selectedColor: AppColors.gold.withOpacity(0.35),
        backgroundColor: Colors.white,
        side: BorderSide(color: AppColors.indigo.withOpacity(0.25)),
        labelStyle: GoogleFonts.sourceSans3(
          color: AppColors.ink,
          fontWeight: FontWeight.w600,
        ),
      ),
      radioTheme: RadioThemeData(
        fillColor: WidgetStateProperty.all(AppColors.indigo),
      ),
      progressIndicatorTheme: const ProgressIndicatorThemeData(
        color: AppColors.gold,
        linearTrackColor: Color(0xFFE7DFC9),
      ),
      cardTheme: CardThemeData(
        color: Colors.white,
        elevation: 0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(14),
          side: BorderSide(color: AppColors.indigo.withOpacity(0.12)),
        ),
      ),
    );
  }
}
