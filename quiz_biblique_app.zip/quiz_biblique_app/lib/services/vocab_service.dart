import 'dart:convert';
import 'dart:math';
import 'package:flutter/services.dart' show rootBundle;
import '../models/lexicon_word.dart';
import '../models/vocab_question.dart';

class VocabService {
  static List<LexiconWord>? _cache;

  /// Charge le(s) lexique(s) disponibles. Le grec est chargé s'il est
  /// présent dans les assets ; sinon on continue avec l'hébreu seul.
  static Future<List<LexiconWord>> loadAll() async {
    if (_cache != null) return _cache!;
    final words = <LexiconWord>[];

    words.addAll(await _loadOne('assets/lexique_hebreu.json', 'hébreu'));

    try {
      words.addAll(await _loadOne('assets/lexique_grec.json', 'grec'));
    } catch (_) {
      // Pas encore de lexique grec fourni : on continue sans bloquer l'app.
    }

    _cache = words;
    return words;
  }

  static Future<List<LexiconWord>> _loadOne(String path, String langue) async {
    final raw = await rootBundle.loadString(path);
    final list = json.decode(raw) as List;
    return list
        .map((e) => LexiconWord.fromJson(e as Map<String, dynamic>, langue))
        .toList();
  }

  static Future<List<String>> languesDisponibles() async {
    final all = await loadAll();
    return all.map((w) => w.langue).toSet().toList()..sort();
  }

  /// Construit une session de questions de vocabulaire, en mélangeant les
  /// deux sens de question (mot -> définition et définition -> mot) et,
  /// si les deux lexiques sont disponibles, l'hébreu et le grec.
  static Future<List<VocabQuestion>> buildSession({
    String? langue, // null = toutes les langues disponibles
    int count = 10,
  }) async {
    final all = await loadAll();
    final pool = langue == null
        ? List<LexiconWord>.from(all)
        : all.where((w) => w.langue == langue).toList();

    pool.shuffle();
    final selection = pool.length > count ? pool.sublist(0, count) : pool;

    final rand = Random();
    final questions = <VocabQuestion>[];

    for (final mot in selection) {
      final direction = rand.nextBool()
          ? VocabDirection.motVersDefinition
          : VocabDirection.definitionVersMot;

      // distracteurs : mots de la même langue, différents du mot ciblé
      final autres = all
          .where((w) => w.langue == mot.langue && w.strongId != mot.strongId)
          .toList()
        ..shuffle();
      final distracteurs = autres.take(3).toList();

      final bonneReponse = direction == VocabDirection.motVersDefinition
          ? mot.definition
          : mot.mot;

      final choix = [
        bonneReponse,
        ...distracteurs.map((d) => direction == VocabDirection.motVersDefinition
            ? d.definition
            : d.mot),
      ]..shuffle();

      questions.add(VocabQuestion(
        mot: mot,
        direction: direction,
        choix: choix,
        bonneReponse: bonneReponse,
      ));
    }

    return questions;
  }
}
