import 'dart:convert';
import 'dart:math';
import 'package:flutter/services.dart' show rootBundle;
import '../models/strong_word.dart';
import '../models/strong_question.dart';

class StrongService {
  static List<StrongWord>? _cache;

  static Future<List<StrongWord>> loadAll() async {
    if (_cache != null) return _cache!;
    final raw = await rootBundle.loadString('assets/strong_lexique.json');
    final list = json.decode(raw) as List;
    _cache = list
        .map((e) => StrongWord.fromJson(e as Map<String, dynamic>))
        .toList();
    return _cache!;
  }

  static Future<List<String>> langues() async {
    final all = await loadAll();
    return all.map((w) => w.langue).toSet().toList()..sort();
  }

  static Future<List<String>> categories({String? langue}) async {
    final all = await loadAll();
    final filtered = langue == null
        ? all
        : all.where((w) => w.langue == langue).toList();
    final cats = filtered.map((w) => w.categorie).where((c) => c.isNotEmpty).toSet().toList();
    cats.sort();
    return cats;
  }

  static Future<List<StrongQuestion>> buildSession({
    String? langue, // null = hébreu + grec mélangés
    String? categorie, // null = toutes catégories
    int count = 10,
  }) async {
    final all = await loadAll();
    var pool = all.where((w) {
      final okLangue = langue == null || w.langue == langue;
      final okCategorie = categorie == null || w.categorie == categorie;
      return okLangue && okCategorie;
    }).toList();

    pool.shuffle();
    if (pool.length > count) {
      pool = pool.sublist(0, count);
    }

    final rand = Random();
    final questions = <StrongQuestion>[];

    for (final mot in pool) {
      final direction = rand.nextBool()
          ? StrongDirection.motVersDefinition
          : StrongDirection.definitionVersMot;

      final autres = all
          .where((w) => w.id != mot.id)
          .toList()
        ..shuffle();
      final distracteurs = autres.take(3).toList();

      final bonneReponse = direction == StrongDirection.motVersDefinition
          ? mot.definition
          : mot.motOriginal;

      final choix = [
        bonneReponse,
        ...distracteurs.map((d) => direction == StrongDirection.motVersDefinition
            ? d.definition
            : d.motOriginal),
      ]..shuffle();

      questions.add(StrongQuestion(
        mot: mot,
        direction: direction,
        choix: choix,
        bonneReponse: bonneReponse,
      ));
    }

    return questions;
  }
}
