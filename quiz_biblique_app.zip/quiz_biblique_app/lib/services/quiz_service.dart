import 'dart:convert';
import 'package:flutter/services.dart' show rootBundle;
import '../models/question.dart';

class QuizService {
  static List<Question>? _cache;

  /// Charge toutes les questions depuis le fichier JSON embarqué (une seule fois).
  static Future<List<Question>> loadAll() async {
    if (_cache != null) return _cache!;
    final raw = await rootBundle.loadString(
      'assets/quiz_biblique_complet.json',
    );
    final data = json.decode(raw) as Map<String, dynamic>;
    final list = data['quiz_biblique_general'] as List;
    _cache = list
        .map((e) => Question.fromJson(e as Map<String, dynamic>))
        .toList();
    return _cache!;
  }

  /// Retourne la liste des niveaux disponibles, dans un ordre pédagogique.
  static Future<List<String>> niveaux() async {
    final all = await loadAll();
    final ordre = ['Enfant', 'Intermédiaire', 'Expert'];
    final present = all.map((q) => q.niveau).toSet();
    return ordre.where(present.contains).toList();
  }

  /// Retourne les catégories disponibles pour un niveau donné (ou toutes si null).
  static Future<List<String>> categories({String? niveau}) async {
    final all = await loadAll();
    final filtered = niveau == null
        ? all
        : all.where((q) => q.niveau == niveau).toList();
    final cats = filtered.map((q) => q.categorie).toSet().toList();
    cats.sort();
    return cats;
  }

  /// Construit une session de quiz : questions mélangées, filtrées par
  /// niveau et/ou catégorie, limitées à [count] questions.
  static Future<List<Question>> buildSession({
    String? niveau,
    String? categorie,
    int count = 10,
  }) async {
    final all = await loadAll();
    var pool = all.where((q) {
      final okNiveau = niveau == null || q.niveau == niveau;
      final okCategorie = categorie == null || q.categorie == categorie;
      return okNiveau && okCategorie;
    }).toList();
    pool.shuffle();
    if (pool.length > count) {
      pool = pool.sublist(0, count);
    }
    return pool;
  }
}
