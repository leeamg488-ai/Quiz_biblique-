import 'lexicon_word.dart';

enum VocabDirection { motVersDefinition, definitionVersMot }

class VocabQuestion {
  final LexiconWord mot;
  final VocabDirection direction;
  final List<String> choix;
  final String bonneReponse;

  VocabQuestion({
    required this.mot,
    required this.direction,
    required this.choix,
    required this.bonneReponse,
  });

  /// Le texte de la question affichée à l'écran.
  String get enonce {
    if (direction == VocabDirection.motVersDefinition) {
      return 'Que signifie ce mot ${mot.langue} ?';
    }
    return 'Quel mot ${mot.langue} correspond à cette définition ?';
  }

  /// Le texte principal mis en avant (le mot, ou la définition).
  String get support {
    if (direction == VocabDirection.motVersDefinition) {
      return mot.mot;
    }
    return mot.definition;
  }
}
