import 'strong_word.dart';

enum StrongDirection { motVersDefinition, definitionVersMot }

class StrongQuestion {
  final StrongWord mot;
  final StrongDirection direction;
  final List<String> choix;
  final String bonneReponse;

  StrongQuestion({
    required this.mot,
    required this.direction,
    required this.choix,
    required this.bonneReponse,
  });

  String get enonce {
    if (direction == StrongDirection.motVersDefinition) {
      return 'Que signifie ce mot ${mot.langue == 'hebreu' ? 'hébreu' : 'grec'} ?';
    }
    return 'Quel mot ${mot.langue == 'hebreu' ? 'hébreu' : 'grec'} correspond à cette définition ?';
  }

  String get support {
    if (direction == StrongDirection.motVersDefinition) {
      return mot.motOriginal;
    }
    return mot.definition;
  }
}
