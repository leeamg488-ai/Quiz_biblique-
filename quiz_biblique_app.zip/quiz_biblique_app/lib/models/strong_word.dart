class StrongWord {
  final int id;
  final String strong; // ex: H113, G26
  final String langue; // "hebreu" ou "grec"
  final String motOriginal;
  final String translitteration;
  final String prononciation;
  final String definition;
  final String categorie;
  final List<String> references;
  final String type; // nom, verbe, adjectif...

  StrongWord({
    required this.id,
    required this.strong,
    required this.langue,
    required this.motOriginal,
    required this.translitteration,
    required this.prononciation,
    required this.definition,
    required this.categorie,
    required this.references,
    required this.type,
  });

  factory StrongWord.fromJson(Map<String, dynamic> json) {
    return StrongWord(
      id: json['id'] as int,
      strong: json['strong'] as String,
      langue: json['langue'] as String,
      motOriginal: json['mot_original'] as String,
      translitteration: json['translitteration'] as String,
      prononciation: json['prononciation'] as String? ?? '',
      definition: json['definition'] as String,
      categorie: json['categorie'] as String? ?? '',
      references: (json['references'] as List?)?.map((e) => e.toString()).toList() ?? [],
      type: json['type'] as String? ?? '',
    );
  }
}
