class Question {
  final String id;
  final String categorie;
  final String niveau;
  final String question;
  final List<String> choix;
  final String bonneReponse;
  final String explication;
  final String reference;
  final int points;

  Question({
    required this.id,
    required this.categorie,
    required this.niveau,
    required this.question,
    required this.choix,
    required this.bonneReponse,
    required this.explication,
    required this.reference,
    required this.points,
  });

  factory Question.fromJson(Map<String, dynamic> json) {
    return Question(
      id: json['id'] as String,
      categorie: json['categorie'] as String,
      niveau: json['niveau'] as String,
      question: json['question'] as String,
      choix: List<String>.from(json['choix'] as List),
      bonneReponse: json['bonne_reponse'] as String,
      explication: json['explication'] as String,
      reference: json['reference'] as String,
      points: json['points'] as int,
    );
  }
}
