class LexiconWord {
  final String strongId; // ex: H0006 ou G0026
  final String mot; // mot en hébreu ou en grec
  final String translitteration;
  final String categorie;
  final String definition;
  final String langue; // "hébreu" ou "grec"

  LexiconWord({
    required this.strongId,
    required this.mot,
    required this.translitteration,
    required this.categorie,
    required this.definition,
    required this.langue,
  });

  factory LexiconWord.fromJson(Map<String, dynamic> json, String langue) {
    return LexiconWord(
      strongId: json['strong_id'] as String,
      mot: json['mot_hebreu'] ?? json['mot_grec'] ?? '',
      translitteration: json['translitteration'] as String? ?? '',
      categorie: json['categorie'] as String? ?? '',
      definition: json['definition'] as String? ?? '',
      langue: langue,
    );
  }
}
