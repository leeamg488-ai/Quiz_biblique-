import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../theme/app_theme.dart';
import '../models/question.dart';
import '../services/quiz_service.dart';
import 'result_screen.dart';

class QuizScreen extends StatefulWidget {
  final String? niveau;
  final String? categorie;

  const QuizScreen({super.key, this.niveau, this.categorie});

  @override
  State<QuizScreen> createState() => _QuizScreenState();
}

class _QuizScreenState extends State<QuizScreen> {
  List<Question> _questions = [];
  int _index = 0;
  int _score = 0;
  String? _reponseChoisie;
  bool _loading = true;

  static const _lettres = ['A', 'B', 'C', 'D'];

  @override
  void initState() {
    super.initState();
    _charger();
  }

  Future<void> _charger() async {
    final session = await QuizService.buildSession(
      niveau: widget.niveau,
      categorie: widget.categorie,
      count: 10,
    );
    setState(() {
      _questions = session;
      _loading = false;
    });
  }

  void _repondre(String choix) {
    if (_reponseChoisie != null) return; // déjà répondu
    setState(() {
      _reponseChoisie = choix;
      if (choix == _questions[_index].bonneReponse) {
        _score += _questions[_index].points;
      }
    });
  }

  void _suivant() {
    if (_index + 1 < _questions.length) {
      setState(() {
        _index++;
        _reponseChoisie = null;
      });
    } else {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (_) => ResultScreen(
            score: _score,
            total: _questions.fold<int>(0, (sum, q) => sum + q.points),
          ),
        ),
      );
    }
  }

  Color? _couleurFond(String choix, Question q) {
    if (_reponseChoisie == null) return null;
    if (choix == q.bonneReponse) return AppColors.sage;
    if (choix == _reponseChoisie) return AppColors.brick.withOpacity(0.75);
    return null;
  }

  bool _estCorrecte(String choix, Question q) => choix == q.bonneReponse;
  bool _estChoisie(String choix) => choix == _reponseChoisie;

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    if (_questions.isEmpty) {
      return Scaffold(
        appBar: AppBar(title: const Text('Quiz biblique')),
        body: const Center(
          child: Text('Aucune question disponible pour cette sélection.'),
        ),
      );
    }

    final q = _questions[_index];
    final repondu = _reponseChoisie != null;

    return Scaffold(
      appBar: AppBar(
        title: Text('Question ${_index + 1} / ${_questions.length}'),
      ),
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 16, 20, 0),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(6),
                child: LinearProgressIndicator(
                  value: (_index + 1) / _questions.length,
                  minHeight: 6,
                ),
              ),
            ),
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Align(
                      alignment: Alignment.centerLeft,
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                        decoration: BoxDecoration(
                          color: AppColors.indigo.withOpacity(0.08),
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Text(
                          q.categorie,
                          style: const TextStyle(
                            color: AppColors.indigo,
                            fontSize: 12,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 14),
                    Text(
                      q.question,
                      style: GoogleFonts.spectral(
                        fontSize: 22,
                        fontWeight: FontWeight.w600,
                        color: AppColors.ink,
                        height: 1.3,
                      ),
                    ),
                    const SizedBox(height: 24),
                    ...List.generate(q.choix.length, (i) {
                      final c = q.choix[i];
                      final correcte = repondu && _estCorrecte(c, q);
                      final mauvaise = repondu && _estChoisie(c) && !_estCorrecte(c, q);
                      return Padding(
                        padding: const EdgeInsets.symmetric(vertical: 6),
                        child: ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: _couleurFond(c, q),
                            padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 16),
                            alignment: Alignment.centerLeft,
                          ),
                          onPressed: () => _repondre(c),
                          child: Row(
                            children: [
                              CircleAvatar(
                                radius: 13,
                                backgroundColor: repondu
                                    ? Colors.white.withOpacity(0.25)
                                    : AppColors.gold,
                                child: Text(
                                  _lettres[i],
                                  style: TextStyle(
                                    fontSize: 12,
                                    fontWeight: FontWeight.bold,
                                    color: repondu ? Colors.white : AppColors.ink,
                                  ),
                                ),
                              ),
                              const SizedBox(width: 12),
                              Expanded(child: Text(c)),
                              if (correcte) const Icon(Icons.check_circle, color: Colors.white, size: 20),
                              if (mauvaise) const Icon(Icons.cancel, color: Colors.white, size: 20),
                            ],
                          ),
                        ),
                      );
                    }),
                    if (repondu) ...[
                      const SizedBox(height: 16),
                      Container(
                        padding: const EdgeInsets.all(14),
                        decoration: BoxDecoration(
                          color: AppColors.gold.withOpacity(0.15),
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: AppColors.gold.withOpacity(0.4)),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                const Icon(Icons.lightbulb_outline, size: 18, color: AppColors.indigo),
                                const SizedBox(width: 6),
                                Text(
                                  'Explication',
                                  style: TextStyle(
                                    fontWeight: FontWeight.w700,
                                    color: AppColors.indigo,
                                    fontSize: 13,
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 6),
                            Text(q.explication),
                            const SizedBox(height: 4),
                            Text(
                              q.reference,
                              style: const TextStyle(fontStyle: FontStyle.italic),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ],
                ),
              ),
            ),
            if (repondu)
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 8, 20, 16),
                child: SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: _suivant,
                    child: Text(
                      _index + 1 < _questions.length
                          ? 'Question suivante'
                          : 'Voir le résultat',
                    ),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}
