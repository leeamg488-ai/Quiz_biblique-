import 'package:flutter/material.dart';
import '../models/question.dart';
import '../services/quiz_service.dart';
import 'result_screen.dart';

class QuizScreen extends StatefulWidget {
  final String? niveau;
  final String? categorie;

  const QuizScreen({super.key, this.niveau, this.categorie});

  @override
  State<QuizScreen> createState() => _QuizScreenState();
}

class _QuizScreenState extends State<QuizScreen> {
  List<Question> _questions = [];
  int _index = 0;
  int _score = 0;
  String? _reponseChoisie;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _charger();
  }

  Future<void> _charger() async {
    final session = await QuizService.buildSession(
      niveau: widget.niveau,
      categorie: widget.categorie,
      count: 10,
    );
    setState(() {
      _questions = session;
      _loading = false;
    });
  }

  void _repondre(String choix) {
    if (_reponseChoisie != null) return; // déjà répondu
    setState(() {
      _reponseChoisie = choix;
      if (choix == _questions[_index].bonneReponse) {
        _score += _questions[_index].points;
      }
    });
  }

  void _suivant() {
    if (_index + 1 < _questions.length) {
      setState(() {
        _index++;
        _reponseChoisie = null;
      });
    } else {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (_) => ResultScreen(
            score: _score,
            total: _questions.length,
          ),
        ),
      );
    }
  }

  Color? _couleurBouton(String choix, Question q) {
    if (_reponseChoisie == null) return null;
    if (choix == q.bonneReponse) return Colors.green.shade400;
    if (choix == _reponseChoisie) return Colors.red.shade300;
    return null;
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    if (_questions.isEmpty) {
      return Scaffold(
        appBar: AppBar(title: const Text('Quiz biblique')),
        body: const Center(
          child: Text('Aucune question disponible pour cette sélection.'),
        ),
      );
    }

    final q = _questions[_index];
    final repondu = _reponseChoisie != null;

    return Scaffold(
      appBar: AppBar(
        title: Text('Question ${_index + 1} / ${_questions.length}'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            LinearProgressIndicator(
              value: (_index + 1) / _questions.length,
            ),
            const SizedBox(height: 16),
            Text(
              q.categorie,
              style: TextStyle(color: Colors.grey.shade600, fontSize: 13),
            ),
            const SizedBox(height: 8),
            Text(
              q.question,
              style: const TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 24),
            ...q.choix.map((c) => Padding(
                  padding: const EdgeInsets.symmetric(vertical: 6),
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: _couleurBouton(c, q),
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      alignment: Alignment.centerLeft,
                    ),
                    onPressed: () => _repondre(c),
                    child: Text(c),
                  ),
                )),
            if (repondu) ...[
              const SizedBox(height: 16),
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.blue.shade50,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(q.explication),
                    const SizedBox(height: 4),
                    Text(
                      q.reference,
                      style: const TextStyle(fontStyle: FontStyle.italic),
                    ),
                  ],
                ),
              ),
            ],
            const Spacer(),
            if (repondu)
              ElevatedButton(
                onPressed: _suivant,
                child: Text(
                  _index + 1 < _questions.length
                      ? 'Question suivante'
                      : 'Voir le résultat',
                ),
              ),
          ],
        ),
      ),
    );
  }
}
