import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import 'home_screen.dart';

class ResultScreen extends StatelessWidget {
  final int score;
  final int total; // score maximum possible pour cette session

  const ResultScreen({super.key, required this.score, required this.total});

  @override
  Widget build(BuildContext context) {
    final ratio = total > 0 ? score / total : 0.0;
    final appreciation = ratio >= 0.8
        ? 'Excellent !'
        : ratio >= 0.5
            ? 'Bien joué'
            : 'Continuez à vous entraîner';

    return Scaffold(
      appBar: AppBar(title: const Text('Résultat')),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // Sceau doré, écho de l'icône de l'app
            Container(
              width: 140,
              height: 140,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: AppColors.indigo,
                border: Border.all(color: AppColors.gold, width: 6),
              ),
              child: const Icon(
                Icons.emoji_events,
                size: 64,
                color: AppColors.gold,
              ),
            ),
            const SizedBox(height: 24),
            Text(
              appreciation,
              style: Theme.of(context).textTheme.headlineMedium,
            ),
            const SizedBox(height: 10),
            Container(width: 60, height: 2, color: AppColors.gold),
            const SizedBox(height: 18),
            Text(
              '$score points',
              style: const TextStyle(
                fontSize: 34,
                fontWeight: FontWeight.bold,
                color: AppColors.indigo,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              'sur $total points possibles',
              style: const TextStyle(color: Colors.black54),
            ),
            const SizedBox(height: 32),
            ElevatedButton(
              onPressed: () {
                Navigator.pushAndRemoveUntil(
                  context,
                  MaterialPageRoute(builder: (_) => const HomeScreen()),
                  (route) => false,
                );
              },
              child: const Text('Rejouer'),
            ),
          ],
        ),
      ),
    );
  }
}
