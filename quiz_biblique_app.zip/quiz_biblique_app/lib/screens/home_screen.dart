import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../services/quiz_service.dart';
import '../services/strong_service.dart';
import '../theme/app_theme.dart';
import 'quiz_screen.dart';
import 'strong_screen.dart';

enum ModeJeu { quiz, strong }

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  ModeJeu _mode = ModeJeu.quiz;
  bool _loading = true;

  // Options du mode Quiz
  List<String> _niveaux = [];
  List<String> _categories = [];
  String? _niveauChoisi;
  String? _categorieChoisie;

  // Options du mode Vocabulaire Strong
  List<String> _stLangues = [];
  List<String> _stCategories = [];
  String? _stLangueChoisie; // null = hébreu + grec mélangés
  String? _stCategorieChoisie;

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    final niveaux = await QuizService.niveaux();
    final stLangues = await StrongService.langues();
    setState(() {
      _niveaux = niveaux;
      _niveauChoisi = niveaux.isNotEmpty ? niveaux.first : null;
      _stLangues = stLangues;
      _loading = false;
    });
    _refreshCategories();
    _refreshStrongCategories();
  }

  Future<void> _refreshCategories() async {
    final cats = await QuizService.categories(niveau: _niveauChoisi);
    setState(() {
      _categories = cats;
      _categorieChoisie = null;
    });
  }

  Future<void> _refreshStrongCategories() async {
    final cats = await StrongService.categories(langue: _stLangueChoisie);
    setState(() {
      _stCategories = cats;
      _stCategorieChoisie = null;
    });
  }

  IconData _iconNiveau(String niveau) {
    switch (niveau) {
      case 'Enfant':
        return Icons.child_care;
      case 'Intermédiaire':
        return Icons.menu_book;
      case 'Expert':
        return Icons.local_fire_department;
      default:
        return Icons.star;
    }
  }

  IconData _iconCategorie(String cat) {
    final c = cat.toLowerCase();
    if (c.contains('femme')) return Icons.female;
    if (c.contains('roi')) return Icons.castle;
    if (c.contains('prophète')) return Icons.campaign;
    if (c.contains('psaume')) return Icons.music_note;
    if (c.contains('évangile')) return Icons.auto_stories;
    if (c.contains('apôtre') || c.contains('actes')) return Icons.groups;
    if (c.contains('doctrine')) return Icons.church;
    if (c.contains('personnage')) return Icons.person;
    if (c.contains('histoire')) return Icons.history_edu;
    if (c.contains('enfant')) return Icons.child_friendly;
    if (c.contains('livre')) return Icons.menu_book_outlined;
    if (c.contains('nom') && c.contains('dieu')) return Icons.auto_awesome;
    if (c.contains('salut') || c.contains('rédemption')) return Icons.brightness_7;
    if (c.contains('amour') || c.contains('grâce')) return Icons.favorite;
    if (c.contains('foi') || c.contains('alliance')) return Icons.handshake;
    return Icons.bookmark_outline;
  }

  void _demarrer() {
    if (_mode == ModeJeu.quiz) {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => QuizScreen(
            niveau: _niveauChoisi,
            categorie: _categorieChoisie,
          ),
        ),
      );
    } else {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => StrongScreen(
            langue: _stLangueChoisie,
            categorie: _stCategorieChoisie,
          ),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }

    return Scaffold(
      body: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // Bandeau d'en-tête
            Container(
              padding: const EdgeInsets.fromLTRB(24, 20, 24, 20),
              decoration: const BoxDecoration(
                color: AppColors.indigo,
                borderRadius: BorderRadius.vertical(bottom: Radius.circular(24)),
              ),
              child: Column(
                children: [
                  Row(
                    children: [
                      Container(
                        width: 52,
                        height: 52,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: AppColors.indigo,
                          border: Border.all(color: AppColors.gold, width: 3),
                        ),
                        alignment: Alignment.center,
                        child: Text(
                          'א',
                          style: GoogleFonts.spectral(
                            color: AppColors.cream,
                            fontWeight: FontWeight.bold,
                            fontSize: 24,
                          ),
                        ),
                      ),
                      const SizedBox(width: 16),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Quiz Biblique',
                              style: GoogleFonts.spectral(
                                color: AppColors.cream,
                                fontSize: 24,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                            Text(
                              'Testez vos connaissances des Écritures',
                              style: TextStyle(
                                color: AppColors.cream.withOpacity(0.75),
                                fontSize: 13,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  SegmentedButton<ModeJeu>(
                    segments: const [
                      ButtonSegment(
                        value: ModeJeu.quiz,
                        label: Text('Quiz biblique'),
                        icon: Icon(Icons.quiz),
                      ),
                      ButtonSegment(
                        value: ModeJeu.strong,
                        label: Text('Vocabulaire Strong'),
                        icon: Icon(Icons.translate),
                      ),
                    ],
                    selected: {_mode},
                    onSelectionChanged: (s) => setState(() => _mode = s.first),
                  ),
                ],
              ),
            ),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(24, 20, 24, 20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Expanded(
                      child: _mode == ModeJeu.quiz
                          ? _buildOptionsQuiz(context)
                          : _buildOptionsStrong(context),
                    ),
                    const SizedBox(height: 12),
                    ElevatedButton.icon(
                      style: ElevatedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(vertical: 16),
                      ),
                      onPressed: _mode == ModeJeu.quiz && _niveauChoisi == null
                          ? null
                          : _demarrer,
                      icon: const Icon(Icons.play_arrow),
                      label: Text(
                        _mode == ModeJeu.quiz
                            ? 'Démarrer le quiz (10 questions)'
                            : 'Démarrer le vocabulaire (10 mots)',
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildOptionsQuiz(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Text('Choisissez un niveau', style: Theme.of(context).textTheme.titleLarge),
        const SizedBox(height: 12),
        Wrap(
          spacing: 10,
          runSpacing: 10,
          children: _niveaux.map((n) {
            final selected = n == _niveauChoisi;
            return ChoiceChip(
              avatar: Icon(
                _iconNiveau(n),
                size: 18,
                color: selected ? AppColors.ink : AppColors.indigo,
              ),
              label: Text(n),
              selected: selected,
              onSelected: (_) {
                setState(() => _niveauChoisi = n);
                _refreshCategories();
              },
            );
          }).toList(),
        ),
        const SizedBox(height: 20),
        Container(height: 1, color: AppColors.gold.withOpacity(0.4)),
        const SizedBox(height: 20),
        Text('Catégorie (optionnel)', style: Theme.of(context).textTheme.titleLarge),
        const SizedBox(height: 8),
        Expanded(
          child: ListView(
            children: [
              _OptionTile(
                icon: Icons.apps,
                label: 'Toutes les catégories',
                selected: _categorieChoisie == null,
                onTap: () => setState(() => _categorieChoisie = null),
              ),
              ..._categories.map((c) => _OptionTile(
                    icon: _iconCategorie(c),
                    label: c,
                    selected: _categorieChoisie == c,
                    onTap: () => setState(() => _categorieChoisie = c),
                  )),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildOptionsStrong(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Text('Langue', style: Theme.of(context).textTheme.titleLarge),
        const SizedBox(height: 8),
        const Text(
          'Les questions passent aléatoirement du mot vers sa définition, '
          'et de la définition vers le mot.',
          style: TextStyle(color: Colors.black54, fontSize: 13),
        ),
        const SizedBox(height: 12),
        Wrap(
          spacing: 10,
          runSpacing: 10,
          children: [
            ChoiceChip(
              label: const Text('Hébreu + Grec'),
              selected: _stLangueChoisie == null,
              onSelected: (_) {
                setState(() => _stLangueChoisie = null);
                _refreshStrongCategories();
              },
            ),
            ..._stLangues.map((l) {
              final label = l == 'hebreu' ? 'Hébreu' : 'Grec';
              final selected = _stLangueChoisie == l;
              return ChoiceChip(
                label: Text(label),
                selected: selected,
                onSelected: (_) {
                  setState(() => _stLangueChoisie = l);
                  _refreshStrongCategories();
                },
              );
            }),
          ],
        ),
        const SizedBox(height: 20),
        Container(height: 1, color: AppColors.gold.withOpacity(0.4)),
        const SizedBox(height: 20),
        Text('Catégorie (optionnel)', style: Theme.of(context).textTheme.titleLarge),
        const SizedBox(height: 8),
        Expanded(
          child: ListView(
            children: [
              _OptionTile(
                icon: Icons.apps,
                label: 'Toutes les catégories',
                selected: _stCategorieChoisie == null,
                onTap: () => setState(() => _stCategorieChoisie = null),
              ),
              ..._stCategories.map((c) => _OptionTile(
                    icon: _iconCategorie(c),
                    label: c,
                    selected: _stCategorieChoisie == c,
                    onTap: () => setState(() => _stCategorieChoisie = c),
                  )),
            ],
          ),
        ),
      ],
    );
  }
}

class _OptionTile extends StatelessWidget {
  final IconData icon;
  final String label;
  final bool selected;
  final VoidCallback onTap;

  const _OptionTile({
    required this.icon,
    required this.label,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Material(
        color: selected ? AppColors.gold.withOpacity(0.18) : Colors.white,
        borderRadius: BorderRadius.circular(12),
        child: InkWell(
          borderRadius: BorderRadius.circular(12),
          onTap: onTap,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: selected
                    ? AppColors.gold
                    : AppColors.indigo.withOpacity(0.12),
              ),
            ),
            child: Row(
              children: [
                Icon(icon, size: 20, color: AppColors.indigo),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    label,
                    style: TextStyle(
                      fontWeight: selected ? FontWeight.w700 : FontWeight.w500,
                      color: AppColors.ink,
                    ),
                  ),
                ),
                if (selected)
                  const Icon(Icons.check_circle, color: AppColors.gold, size: 20),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
