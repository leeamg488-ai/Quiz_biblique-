import 'package:flutter/material.dart';
import '../services/quiz_service.dart';
import '../services/vocab_service.dart';
import 'quiz_screen.dart';
import 'vocab_screen.dart';

enum ModeJeu { quiz, vocabulaire }

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  ModeJeu _mode = ModeJeu.quiz;
  bool _loading = true;

  // Options du mode Quiz
  List<String> _niveaux = [];
  List<String> _categories = [];
  String? _niveauChoisi;
  String? _categorieChoisie;

  // Options du mode Vocabulaire
  List<String> _langues = [];
  String? _langueChoisie; // null = hébreu + grec mélangés

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    final niveaux = await QuizService.niveaux();
    final langues = await VocabService.languesDisponibles();
    setState(() {
      _niveaux = niveaux;
      _niveauChoisi = niveaux.isNotEmpty ? niveaux.first : null;
      _langues = langues;
      _langueChoisie = null; // toutes langues par défaut (mélange)
      _loading = false;
    });
    _refreshCategories();
  }

  Future<void> _refreshCategories() async {
    final cats = await QuizService.categories(niveau: _niveauChoisi);
    setState(() {
      _categories = cats;
      _categorieChoisie = null;
    });
  }

  void _demarrer() {
    if (_mode == ModeJeu.quiz) {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => QuizScreen(
            niveau: _niveauChoisi,
            categorie: _categorieChoisie,
          ),
        ),
      );
    } else {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => VocabScreen(langue: _langueChoisie),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }

    return Scaffold(
      appBar: AppBar(title: const Text('Quiz biblique')),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            SegmentedButton<ModeJeu>(
              segments: const [
                ButtonSegment(
                  value: ModeJeu.quiz,
                  label: Text('Quiz biblique'),
                  icon: Icon(Icons.quiz),
                ),
                ButtonSegment(
                  value: ModeJeu.vocabulaire,
                  label: Text('Vocabulaire'),
                  icon: Icon(Icons.translate),
                ),
              ],
              selected: {_mode},
              onSelectionChanged: (s) => setState(() => _mode = s.first),
            ),
            const SizedBox(height: 24),
            Expanded(
              child: _mode == ModeJeu.quiz
                  ? _buildOptionsQuiz()
                  : _buildOptionsVocab(),
            ),
            const SizedBox(height: 12),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                padding: const EdgeInsets.symmetric(vertical: 16),
              ),
              onPressed: _mode == ModeJeu.quiz && _niveauChoisi == null
                  ? null
                  : _demarrer,
              child: Text(
                _mode == ModeJeu.quiz
                    ? 'Démarrer le quiz (10 questions)'
                    : 'Démarrer le vocabulaire (10 mots)',
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildOptionsQuiz() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        const Text(
          'Choisissez un niveau',
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 12),
        Wrap(
          spacing: 8,
          children: _niveaux.map((n) {
            final selected = n == _niveauChoisi;
            return ChoiceChip(
              label: Text(n),
              selected: selected,
              onSelected: (_) {
                setState(() => _niveauChoisi = n);
                _refreshCategories();
              },
            );
          }).toList(),
        ),
        const SizedBox(height: 24),
        const Text(
          'Catégorie (optionnel)',
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 12),
        Expanded(
          child: ListView(
            children: [
              RadioListTile<String?>(
                title: const Text('Toutes les catégories'),
                value: null,
                groupValue: _categorieChoisie,
                onChanged: (v) => setState(() => _categorieChoisie = v),
              ),
              ..._categories.map((c) => RadioListTile<String?>(
                    title: Text(c),
                    value: c,
                    groupValue: _categorieChoisie,
                    onChanged: (v) => setState(() => _categorieChoisie = v),
                  )),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildOptionsVocab() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        const Text(
          'Langue',
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 8),
        const Text(
          'Les questions passent aléatoirement du mot vers sa traduction, '
          'et de la traduction vers le mot.',
          style: TextStyle(color: Colors.black54, fontSize: 13),
        ),
        const SizedBox(height: 12),
        RadioListTile<String?>(
          title: const Text('Hébreu + Grec mélangés'),
          value: null,
          groupValue: _langueChoisie,
          onChanged: (v) => setState(() => _langueChoisie = v),
        ),
        ..._langues.map((l) => RadioListTile<String?>(
              title: Text(l[0].toUpperCase() + l.substring(1)),
              value: l,
              groupValue: _langueChoisie,
              onChanged: (v) => setState(() => _langueChoisie = v),
            )),
        if (_langues.length < 2)
          Padding(
            padding: const EdgeInsets.only(top: 12),
            child: Text(
              'Le lexique grec n\'est pas encore ajouté : seul l\'hébreu '
              'est disponible pour le moment.',
              style: TextStyle(color: Colors.orange.shade800, fontSize: 13),
            ),
          ),
      ],
    );
  }
}
