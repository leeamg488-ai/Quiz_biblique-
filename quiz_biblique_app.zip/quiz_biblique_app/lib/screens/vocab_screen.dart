import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../models/vocab_question.dart';
import '../services/vocab_service.dart';
import 'result_screen.dart';

class VocabScreen extends StatefulWidget {
  final String? langue; // null = hébreu + grec mélangés

  const VocabScreen({super.key, this.langue});

  @override
  State<VocabScreen> createState() => _VocabScreenState();
}

class _VocabScreenState extends State<VocabScreen> {
  List<VocabQuestion> _questions = [];
  int _index = 0;
  int _score = 0;
  String? _reponseChoisie;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _charger();
  }

  Future<void> _charger() async {
    final session = await VocabService.buildSession(
      langue: widget.langue,
      count: 10,
    );
    setState(() {
      _questions = session;
      _loading = false;
    });
  }

  void _repondre(String choix) {
    if (_reponseChoisie != null) return;
    setState(() {
      _reponseChoisie = choix;
      if (choix == _questions[_index].bonneReponse) {
        _score += 10;
      }
    });
  }

  void _suivant() {
    if (_index + 1 < _questions.length) {
      setState(() {
        _index++;
        _reponseChoisie = null;
      });
    } else {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (_) => ResultScreen(score: _score, total: _questions.length * 10),
        ),
      );
    }
  }

  Color? _couleurBouton(String choix, VocabQuestion q) {
    if (_reponseChoisie == null) return null;
    if (choix == q.bonneReponse) return AppColors.sage;
    if (choix == _reponseChoisie) return AppColors.brick.withOpacity(0.75);
    return null;
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    if (_questions.isEmpty) {
      return Scaffold(
        appBar: AppBar(title: const Text('Vocabulaire')),
        body: const Center(
          child: Text('Aucun mot disponible pour cette sélection.'),
        ),
      );
    }

    final q = _questions[_index];
    final repondu = _reponseChoisie != null;
    final motVersDef = q.direction == VocabDirection.motVersDefinition;

    return Scaffold(
      appBar: AppBar(
        title: Text('Mot ${_index + 1} / ${_questions.length}'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            LinearProgressIndicator(value: (_index + 1) / _questions.length),
            const SizedBox(height: 16),
            Text(
              '${q.mot.langue.toUpperCase()} · ${q.mot.categorie}',
              style: TextStyle(color: Colors.grey.shade600, fontSize: 13),
            ),
            const SizedBox(height: 8),
            Text(
              q.enonce,
              style: const TextStyle(fontSize: 15, color: Colors.black54),
            ),
            const SizedBox(height: 8),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 12),
              decoration: BoxDecoration(
                color: AppColors.gold.withOpacity(0.15),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Column(
                children: [
                  Text(
                    q.support,
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: motVersDef ? 26 : 17,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  if (motVersDef && q.mot.translitteration.isNotEmpty) ...[
                    const SizedBox(height: 4),
                    Text(
                      q.mot.translitteration,
                      style: const TextStyle(
                        fontStyle: FontStyle.italic,
                        color: Colors.black54,
                      ),
                    ),
                  ],
                ],
              ),
            ),
            const SizedBox(height: 20),
            ...q.choix.map((c) => Padding(
                  padding: const EdgeInsets.symmetric(vertical: 6),
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: _couleurBouton(c, q),
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      alignment: Alignment.centerLeft,
                    ),
                    onPressed: () => _repondre(c),
                    child: Text(c, textAlign: TextAlign.left),
                  ),
                )),
            const Spacer(),
            if (repondu)
              ElevatedButton(
                onPressed: _suivant,
                child: Text(
                  _index + 1 < _questions.length ? 'Mot suivant' : 'Voir le résultat',
                ),
              ),
          ],
        ),
      ),
    );
  }
}
