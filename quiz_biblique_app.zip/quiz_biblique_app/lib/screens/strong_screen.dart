import 'package:flutter/material.dart';
import '../models/strong_question.dart';
import '../services/strong_service.dart';
import '../theme/app_theme.dart';
import 'result_screen.dart';

class StrongScreen extends StatefulWidget {
  final String? langue;
  final String? categorie;

  const StrongScreen({super.key, this.langue, this.categorie});

  @override
  State<StrongScreen> createState() => _StrongScreenState();
}

class _StrongScreenState extends State<StrongScreen> {
  List<StrongQuestion> _questions = [];
  int _index = 0;
  int _score = 0;
  String? _reponseChoisie;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _charger();
  }

  Future<void> _charger() async {
    final session = await StrongService.buildSession(
      langue: widget.langue,
      categorie: widget.categorie,
      count: 10,
    );
    setState(() {
      _questions = session;
      _loading = false;
    });
  }

  void _repondre(String choix) {
    if (_reponseChoisie != null) return;
    setState(() {
      _reponseChoisie = choix;
      if (choix == _questions[_index].bonneReponse) {
        _score += 10;
      }
    });
  }

  void _suivant() {
    if (_index + 1 < _questions.length) {
      setState(() {
        _index++;
        _reponseChoisie = null;
      });
    } else {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (_) => ResultScreen(score: _score, total: _questions.length * 10),
        ),
      );
    }
  }

  Color? _couleurFond(String choix, StrongQuestion q) {
    if (_reponseChoisie == null) return null;
    if (choix == q.bonneReponse) return AppColors.sage;
    if (choix == _reponseChoisie) return AppColors.brick.withOpacity(0.75);
    return null;
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    if (_questions.isEmpty) {
      return Scaffold(
        appBar: AppBar(title: const Text('Vocabulaire Strong')),
        body: const Center(
          child: Text('Aucun mot disponible pour cette sélection.'),
        ),
      );
    }

    final q = _questions[_index];
    final repondu = _reponseChoisie != null;
    final motVersDef = q.direction == StrongDirection.motVersDefinition;

    return Scaffold(
      appBar: AppBar(title: Text('Mot ${_index + 1} / ${_questions.length}')),
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 16, 20, 0),
              child: LinearProgressIndicator(value: (_index + 1) / _questions.length),
            ),
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Align(
                      alignment: Alignment.centerLeft,
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                        decoration: BoxDecoration(
                          color: AppColors.indigo.withOpacity(0.08),
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Text(
                          '${q.mot.strong} · ${q.mot.categorie}',
                          style: const TextStyle(
                            color: AppColors.indigo,
                            fontSize: 12,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 12),
                    Text(
                      q.enonce,
                      style: const TextStyle(fontSize: 15, color: Colors.black54),
                    ),
                    const SizedBox(height: 8),
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 12),
                      decoration: BoxDecoration(
                        color: AppColors.gold.withOpacity(0.15),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Column(
                        children: [
                          Text(
                            q.support,
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              fontSize: motVersDef ? 30 : 17,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          if (motVersDef) ...[
                            const SizedBox(height: 6),
                            Text(
                              '${q.mot.translitteration} · ${q.mot.prononciation}',
                              style: const TextStyle(
                                fontStyle: FontStyle.italic,
                                color: Colors.black54,
                              ),
                            ),
                          ],
                        ],
                      ),
                    ),
                    const SizedBox(height: 20),
                    ...q.choix.map((c) => Padding(
                          padding: const EdgeInsets.symmetric(vertical: 6),
                          child: ElevatedButton(
                            style: ElevatedButton.styleFrom(
                              backgroundColor: _couleurFond(c, q),
                              padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 16),
                              alignment: Alignment.centerLeft,
                            ),
                            onPressed: () => _repondre(c),
                            child: Text(c, textAlign: TextAlign.left),
                          ),
                        )),
                    if (repondu && q.mot.references.isNotEmpty) ...[
                      const SizedBox(height: 12),
                      Text(
                        'Référence : ${q.mot.references.first}',
                        style: const TextStyle(fontStyle: FontStyle.italic, fontSize: 13),
                      ),
                    ],
                  ],
                ),
              ),
            ),
            if (repondu)
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 8, 20, 16),
                child: SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: _suivant,
                    child: Text(
                      _index + 1 < _questions.length ? 'Mot suivant' : 'Voir le résultat',
                    ),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}
