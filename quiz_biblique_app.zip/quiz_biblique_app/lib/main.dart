import 'package:flutter/material.dart';
import 'screens/home_screen.dart';

void main() {
  runApp(const QuizBibliqueApp());
}

class QuizBibliqueApp extends StatelessWidget {
  const QuizBibliqueApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Quiz biblique',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorSchemeSeed: const Color(0xFF2E5477),
        useMaterial3: true,
      ),
      home: const HomeScreen(),
    );
  }
}
