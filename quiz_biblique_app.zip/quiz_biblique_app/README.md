# Quiz biblique — app Flutter (v1)

## Ce que contient ce projet
- Écran d'accueil : choix du niveau (Enfant / Intermédiaire / Expert) et d'une catégorie optionnelle.
- Écran de quiz : 10 questions à choix multiples, feedback immédiat (bonne/mauvaise réponse en couleur), explication + référence biblique affichées après chaque réponse.
- Écran de résultat : score final, bouton "Rejouer".
- 1279 questions embarquées (`assets/quiz_biblique_complet.json`).

## Installer Flutter (si ce n'est pas déjà fait)
1. Suivre https://docs.flutter.dev/get-started/install pour votre système.
2. Vérifier l'installation : `flutter doctor` (doit confirmer qu'Android toolchain est OK).

## Lancer le projet
```bash
cd quiz_biblique_app
flutter pub get
flutter run
```
Choisissez un émulateur Android ou branchez un téléphone (mode développeur + débogage USB activé) quand `flutter run` vous le demande.

## Générer un APK installable
```bash
flutter build apk --release
```
L'APK se trouve ensuite dans `build/app/outputs/flutter-apk/app-release.apk`, à transférer sur un téléphone Android pour installation directe.

## Structure du code
```
lib/
  main.dart              -> point d'entrée, thème de l'app
  models/question.dart   -> structure d'une question
  services/quiz_service.dart -> chargement du JSON, filtrage par niveau/catégorie
  screens/home_screen.dart   -> sélection niveau + catégorie
  screens/quiz_screen.dart   -> déroulé des questions
  screens/result_screen.dart -> score final
assets/
  quiz_biblique_complet.json -> vos 1279 questions
```

## Prochaines pistes d'amélioration (quand vous voudrez)
- Ajouter le mode vocabulaire hébreu/grec (basé sur votre lexique déjà construit).
- Sauvegarder les scores localement (ex. package `shared_preferences`) pour un historique.
- Ajouter un chronomètre par question.
- Ajouter des icônes/illustrations par catégorie.
