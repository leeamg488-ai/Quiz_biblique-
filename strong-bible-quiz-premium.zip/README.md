# 📖 Quiz Lexique Strong — Bible Hébreu & Grec

Un jeu de quiz interactif basé sur le **lexique Strong** (575 mots bibliques en hébreu et grec), jouable directement dans le navigateur.

---

## 🚀 Démonstration en ligne

👉 [Jouer au Quiz](https://votre-username.github.io/nom-du-repo/quiz_game.html)

*(Remplacez par votre URL GitHub Pages après déploiement)*

---

## 📦 Contenu du projet

| Fichier | Description |
|---------|-------------|
| `quiz_game.html` | **Jeu complet** (HTML + CSS + JS + données intégrées) — fonctionne hors-ligne |
| `strong_lexicon.json` | Données brutes du lexique (575 entrées) |
| `README.md` | Ce fichier |

---

## 🎮 Modes de jeu

| Mode | Description |
|------|-------------|
| 🎯 **Définition → Mot** | Trouvez le mot original à partir de sa définition |
| 🔤 **Translittération → Mot** | Reconnaissez le mot hébreu/grec à partir de sa translittération |
| 📖 **Référence → Mot** | Identifiez le mot à partir du verset biblique de référence |
| 🎲 **Mode aléatoire** | Mélange des 3 modes précédents |

---

## ⚙️ Filtres disponibles

- **Langue** : Hébreu uniquement / Grec uniquement / Les deux
- **Catégorie** : 13 catégories thématiques (Noms de Dieu, Salut & Rédemption, Adoration & Culte, etc.)
- **Nombre de questions** : 10, 20, 30, 50 ou toutes les entrées

---

## 📊 Statistiques du lexique

- **575 entrées** totales
- **289 mots hébreux** (Strong Hxxx)
- **286 mots grecs** (Strong Gxxxx)
- **13 catégories** thématiques
- Chaque entrée contient : mot original, translittération, prononciation, définition, catégorie, référence biblique, type grammatical, occurrences

---

## 🛠️ Déploiement sur GitHub Pages

1. **Créer un repository** sur GitHub
2. **Uploader les fichiers** :
   ```bash
   git init
   git add .
   git commit -m "Initial commit"
   git branch -M main
   git remote add origin https://github.com/votre-username/nom-du-repo.git
   git push -u origin main
   ```
3. **Activer GitHub Pages** :
   - Allez dans **Settings → Pages**
   - Source : **Deploy from a branch**
   - Branch : **main** → **/(root)**
   - Cliquez **Save**
4. **Accédez au jeu** : `https://votre-username.github.io/nom-du-repo/quiz_game.html`

---

## 📝 Structure des données

```json
{
  "id": 4,
  "strong": "H113",
  "langue": "hebreu",
  "numero": 113,
  "mot_original": "אדון",
  "translitteration": "Adon",
  "prononciation": "A-done",
  "definition": "Seigneur,maître,propriétaire ou souverain (humain ou divin).",
  "categorie": "Noms de Dieu",
  "references": ["Josué 3:11"],
  "type": "nom",
  "occurrences": 335,
  "recherche": "h113adon a-done אדוןseigneur...",
  "audio": "H113.mp3",
  "image": null
}
```

---

## 🔊 Fichiers audio

Les entrées contiennent des liens vers des fichiers MP3 (`Hxxx.mp3`, `Gxxxx.mp3`).
Pour ajouter l'audio :
1. Créez un dossier `assets/audio/`
2. Placez vos fichiers MP3 avec les noms correspondants
3. Modifiez le code pour charger l'audio

---

## 📱 Compatibilité

- ✅ Chrome / Firefox / Safari / Edge
- ✅ iOS / Android
- ✅ Fonctionne hors-ligne (fichier unique)

---

## 📜 Licence

Données issues du lexique Strong (domaine public).
Code du quiz : libre d'utilisation.

---

*"Étudie pour te présenter devant Dieu, ouvrier qui n'a point à rougir, dispensant la parole de la vérité avec droiture." — 2 Timothée 2:15*
