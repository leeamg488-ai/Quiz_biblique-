import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI, Type } from '@google/genai';
import dotenv from 'dotenv';

dotenv.config();

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Middleware for parsing JSON with a high limit for larger text datasets
  app.use(express.json({ limit: '50mb' }));
  app.use(express.urlencoded({ extended: true, limit: '50mb' }));

  // API: Health check
  app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', time: new Date().toISOString() });
  });

  // API: Parse raw text into structured Strong's lexicon entries
  app.post('/api/parse-strong', async (req, res) => {
    try {
      const { rawText, startId = 101 } = req.body;

      if (!rawText || typeof rawText !== 'string' || rawText.trim() === '') {
        return res.status(400).json({ error: 'Le texte brut est requis pour la conversion.' });
      }

      // Check for GEMINI_API_KEY environment variable
      const apiKey = process.env.GEMINI_API_KEY;
      if (!apiKey) {
        return res.status(500).json({
          error: "Clé API Gemini manquante. Veuillez configurer votre clé dans le panneau 'Settings > Secrets' de Google AI Studio."
        });
      }

      // Lazy-initialize the GoogleGenAI client to avoid crashes on startup if key is missing
      const ai = new GoogleGenAI({
        apiKey,
        httpOptions: {
          headers: {
            'User-Agent': 'aistudio-build',
          }
        }
      });

      const systemInstruction = `Tu es un expert mondial en bases de données bibliques, en grec et hébreu biblique, et en lexique Strong.
Ta mission est de transformer le texte brut fourni par l'utilisateur contenant des entrées du lexique Strong en un tableau JSON uniforme et valide, optimisé pour une application de quiz biblique.

Règles fondamentales :
1. Ne jamais modifier les informations bibliques historiques.
2. Ne jamais inventer une définition. Si elle n'est pas claire, synthétise-la proprement d'après le texte brut.
3. Conserver exactement le numéro Strong (ex: H3068, G2316).
4. Conserver le mot original en caractères hébreux ou grecs.
5. Conserver la translittération et la prononciation exacte en français.
6. Catégoriser logiquement chaque mot (ex: "Noms de Dieu", "Concepts Spirituels", "Attributs de Christ", "Création", "Vertus Chrétiennes", "Anthropologie").
7. Remplir le champ "references" avec un tableau de références bibliques présentes dans le texte ou emblématiques (ex: ["Genèse 2:4"]).
8. Le champ "type" doit indiquer la nature grammaticale (nom propre, nom masculin, verbe, adjectif, etc.).
9. Le champ "occurrences" doit être un nombre entier représentant les occurrences dans la Bible hébraïque ou le Nouveau Testament. Si non mentionné, utilise une estimation réaliste ou 1.
10. Remplir le champ "recherche" avec une chaîne de caractères en minuscules contenant tous les mots-clés utiles pour faciliter la recherche rapide côté client (numéro Strong, translittération, prononciation, définition courte, catégorie, références).
11. Remplir le champ "audio" par le numéro Strong suivi de ".mp3" (ex: "H3068.mp3").
12. Le champ "image" doit être systématiquement null.
13. Incrémenter les ID séquentiellement à partir de l'index de départ : ${startId}.

Structure exacte d'une entrée :
{
  "id": number,
  "strong": string, // ex: "H3068"
  "langue": "hebreu" | "grec", // "hebreu" si commence par H, "grec" si commence par G
  "numero": number, // la partie numérique, ex: 3068
  "mot_original": string, // ex: "יהוה" ou "θεός"
  "translitteration": string, // ex: "YHWH / Yahweh" ou "Theos"
  "prononciation": string, // ex: "Ya-oué" ou "Thé-os"
  "definition": string, // Définition complète et claire en français
  "categorie": string, // Catégorie thématique en français
  "references": string[], // ex: ["Genèse 2:4"]
  "type": string, // ex: "nom", "verbe", "adjectif"
  "occurrences": number,
  "recherche": string, // Mots-clés en minuscules séparés par des espaces
  "audio": string, // ex: "H3068.mp3"
  "image": null
}

Renvoie UNIQUEMENT un tableau JSON valide. Ne fournis aucune autre explication ni texte d'accompagnement.`;

      const prompt = `Voici les entrées brutes à convertir en JSON uniforme :
${rawText}

Assure-toi de traiter toutes les entrées fournies. Renvoie un tableau JSON conforme.`;

      const response = await ai.models.generateContent({
        model: 'gemini-3.5-flash',
        contents: prompt,
        config: {
          systemInstruction,
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.ARRAY,
            description: "Tableau d'entrées du lexique Strong formatées uniformément",
            items: {
              type: Type.OBJECT,
              properties: {
                id: { type: Type.INTEGER },
                strong: { type: Type.STRING },
                langue: { type: Type.STRING },
                numero: { type: Type.INTEGER },
                mot_original: { type: Type.STRING },
                translitteration: { type: Type.STRING },
                prononciation: { type: Type.STRING },
                definition: { type: Type.STRING },
                categorie: { type: Type.STRING },
                references: {
                  type: Type.ARRAY,
                  items: { type: Type.STRING }
                },
                type: { type: Type.STRING },
                occurrences: { type: Type.INTEGER },
                recherche: { type: Type.STRING },
                audio: { type: Type.STRING },
                image: { type: Type.NULL }
              },
              required: [
                'id', 'strong', 'langue', 'numero', 'mot_original', 'translitteration',
                'prononciation', 'definition', 'categorie', 'references', 'type',
                'occurrences', 'recherche', 'audio'
              ]
            }
          }
        }
      });

      const responseText = response.text;
      if (!responseText) {
        throw new Error("Le modèle n'a renvoyé aucune donnée.");
      }

      const parsedJson = JSON.parse(responseText.trim());
      res.json(parsedJson);
    } catch (error: any) {
      console.error('Erreur lors du traitement Gemini:', error);
      res.status(500).json({
        error: "Erreur lors de la conversion par l'IA.",
        details: error.message || String(error)
      });
    }
  });

  // Serve static assets and bundle inside 'dist' in production
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Serveur démarré avec succès sur http://localhost:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Erreur lors du démarrage du serveur:', err);
});
