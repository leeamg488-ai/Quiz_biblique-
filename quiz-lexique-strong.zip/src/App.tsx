import React, { useState, useEffect } from 'react';
import { StrongEntry } from './types';
import { initialStrongData } from './data/initialStrongData';
import DictionaryBrowser from './components/DictionaryBrowser';
import QuizGame from './components/QuizGame';
import AIParser from './components/AIParser';
import DatabaseHub from './components/DatabaseHub';
import { BookOpen, Trophy, Sparkles, Database, Heart, BookMarked, HelpCircle } from 'lucide-react';
import { motion } from 'motion/react';

const LOCAL_STORAGE_KEY = 'bible_strong_lexicon_db';

export default function App() {
  const [entries, setEntries] = useState<StrongEntry[]>([]);
  const [activeTab, setActiveTab] = useState<'dictionary' | 'quiz' | 'parser' | 'database'>('dictionary');
  const [editingEntry, setEditingEntry] = useState<StrongEntry | null>(null);

  // Load entries from localStorage or default to initial dataset on mount
  useEffect(() => {
    const saved = localStorage.getItem(LOCAL_STORAGE_KEY);
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          // Si le stockage local est obsolète ou contient moins d'entrées que le jeu de données initial (152 mots),
          // on fusionne pour garantir que toutes les entrées par défaut sont présentes tout en préservant d'éventuels ajouts de l'utilisateur.
          const merged = [...parsed];
          let updated = false;
          initialStrongData.forEach(initItem => {
            const exists = merged.some(item => item.id === initItem.id || item.strong.toLowerCase() === initItem.strong.toLowerCase());
            if (!exists) {
              merged.push(initItem);
              updated = true;
            }
          });
          if (updated) {
            // Trier de manière cohérente : d'abord hébreu, puis grec, triés par numéro Strong
            merged.sort((a, b) => {
              if (a.langue !== b.langue) {
                return a.langue === 'hebreu' ? -1 : 1;
              }
              return a.numero - b.numero;
            });
            setEntries(merged);
            localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(merged));
          } else {
            setEntries(parsed);
          }
          return;
        }
      } catch (e) {
        console.error("Erreur lors de la lecture du dictionnaire local:", e);
      }
    }
    // Set seed data if none exists
    setEntries(initialStrongData);
    localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(initialStrongData));
  }, []);

  // Sync to local storage on changes
  const saveToStorage = (updatedEntries: StrongEntry[]) => {
    setEntries(updatedEntries);
    localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(updatedEntries));
  };

  // HANDLERS
  const handleAddEntry = (entry: StrongEntry) => {
    const updated = [entry, ...entries];
    saveToStorage(updated);
  };

  const handleImportJson = (imported: StrongEntry[]) => {
    saveToStorage(imported);
  };

  const handleClearDatabase = () => {
    saveToStorage([]);
  };

  const handleResetToDefault = () => {
    saveToStorage(initialStrongData);
  };

  const handleDeleteEntry = (id: number) => {
    const updated = entries.filter(e => e.id !== id);
    saveToStorage(updated);
  };

  const handleMergeParsedEntries = (newEntries: StrongEntry[]) => {
    // Prevent duplicate Strong numbers (overwrite if exists, otherwise append)
    let updated = [...entries];
    newEntries.forEach(newWord => {
      const existingIdx = updated.findIndex(e => e.strong.toUpperCase() === newWord.strong.toUpperCase());
      if (existingIdx !== -1) {
        // Update existing in-place
        updated[existingIdx] = { ...newWord, id: updated[existingIdx].id };
      } else {
        // Generate valid next sequential ID
        const nextId = updated.length > 0 ? Math.max(...updated.map(e => e.id)) + 1 : 1;
        updated.push({ ...newWord, id: nextId });
      }
    });
    saveToStorage(updated);
  };

  return (
    <div className="min-h-screen flex flex-col justify-between text-gray-800">
      {/* Dynamic Grid Background Overlay */}
      <div className="absolute inset-0 bg-[radial-gradient(#e5e7eb_1px,transparent_1px)] [background-size:16px_16px] [mask-image:radial-gradient(ellipse_50%_50%_at_50%_50%,#000_70%,transparent_100%)] opacity-30 pointer-events-none" />

      {/* Main Content Area */}
      <div className="relative z-10 w-full max-w-6xl mx-auto px-4 py-8 space-y-8 flex-1">
        {/* Header Block */}
        <header className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 pb-6 border-b border-gray-100">
          <div className="space-y-1">
            <h1 className="text-3xl font-black font-display text-gray-900 tracking-tight flex items-center gap-2">
              📖 Quiz Lexique Strong
            </h1>
            <p className="text-xs text-gray-500 font-medium">
              Plateforme d'apprentissage, dictionnaire hébreu / grec biblique, et compilateur JSON.
            </p>
          </div>

          {/* Active stats badge */}
          <div className="bg-white px-4 py-2 rounded-2xl border border-gray-100 shadow-xs flex items-center gap-3 text-xs">
            <div className="flex flex-col">
              <span className="font-mono font-bold text-gray-800">{entries.length} mots</span>
              <span className="text-[10px] text-gray-400 font-medium uppercase">Dictionnaire actif</span>
            </div>
            <div className="h-6 w-[1px] bg-gray-100" />
            <div className="flex gap-1.5 text-[10px] font-mono">
              <span className="bg-amber-50 text-amber-800 px-1.5 py-0.5 rounded font-bold">
                H: {entries.filter(e => e.langue === 'hebreu').length}
              </span>
              <span className="bg-blue-50 text-blue-800 px-1.5 py-0.5 rounded font-bold">
                G: {entries.filter(e => e.langue === 'grec').length}
              </span>
            </div>
          </div>
        </header>

        {/* Global tab navigation menu */}
        <nav className="flex flex-wrap bg-white p-1.5 rounded-2xl border border-gray-100 shadow-xs max-w-2xl">
          <button
            onClick={() => setActiveTab('dictionary')}
            className={`flex items-center gap-2 px-5 py-3 text-xs font-bold rounded-xl transition-all cursor-pointer ${
              activeTab === 'dictionary'
                ? 'bg-amber-500 text-white shadow-md shadow-amber-500/10'
                : 'text-gray-500 hover:text-gray-800 hover:bg-gray-50'
            }`}
          >
            <BookMarked className="h-4 w-4" /> Dictionnaire
          </button>
          
          <button
            onClick={() => setActiveTab('quiz')}
            className={`flex items-center gap-2 px-5 py-3 text-xs font-bold rounded-xl transition-all cursor-pointer ${
              activeTab === 'quiz'
                ? 'bg-amber-500 text-white shadow-md shadow-amber-500/10'
                : 'text-gray-500 hover:text-gray-800 hover:bg-gray-50'
            }`}
          >
            <Trophy className="h-4 w-4" /> Quiz Interactif
          </button>

          <button
            onClick={() => setActiveTab('parser')}
            className={`flex items-center gap-2 px-5 py-3 text-xs font-bold rounded-xl transition-all cursor-pointer ${
              activeTab === 'parser'
                ? 'bg-amber-500 text-white shadow-md shadow-amber-500/10'
                : 'text-gray-500 hover:text-gray-800 hover:bg-gray-50'
            }`}
          >
            <Sparkles className="h-4 w-4" /> Convertisseur IA
          </button>

          <button
            onClick={() => setActiveTab('database')}
            className={`flex items-center gap-2 px-5 py-3 text-xs font-bold rounded-xl transition-all cursor-pointer ${
              activeTab === 'database'
                ? 'bg-amber-500 text-white shadow-md shadow-amber-500/10'
                : 'text-gray-500 hover:text-gray-800 hover:bg-gray-50'
            }`}
          >
            <Database className="h-4 w-4" /> Base de Données
          </button>
        </nav>

        {/* Tab contents mounting */}
        <main className="min-h-[400px]">
          {activeTab === 'dictionary' && (
            <DictionaryBrowser 
              entries={entries} 
              onDeleteEntry={handleDeleteEntry}
              onEditEntry={(entry) => {
                setEditingEntry(entry);
                setActiveTab('database');
              }}
            />
          )}

          {activeTab === 'quiz' && (
            <QuizGame entries={entries} />
          )}

          {activeTab === 'parser' && (
            <AIParser 
              entriesCount={entries.length} 
              onMergeEntries={handleMergeParsedEntries}
            />
          )}

          {activeTab === 'database' && (
            <DatabaseHub 
              entries={entries}
              onAddEntry={handleAddEntry}
              onImportJson={handleImportJson}
              onClearDatabase={handleClearDatabase}
              onResetToDefault={handleResetToDefault}
            />
          )}
        </main>
      </div>

      {/* Footer information block */}
      <footer className="w-full bg-white border-t border-gray-100 py-6 mt-12 relative z-10 text-center text-xs text-gray-400 space-y-1 font-sans">
        <p className="flex items-center justify-center gap-1">
          Développé avec précision théologique et technologique <Heart className="h-3 w-3 text-red-500 fill-red-500" />
        </p>
        <p className="font-mono text-[10px]">
          Format JSON compatible Flutter • React • Supabase • SQLite • PostgreSQL • Firebase
        </p>
      </footer>
    </div>
  );
}
