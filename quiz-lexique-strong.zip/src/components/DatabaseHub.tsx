import React, { useState } from 'react';
import { StrongEntry } from '../types';
import { 
  Database, Copy, Check, Download, Upload, Trash2, PlusCircle, AlertCircle, RefreshCw, Eye 
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface DatabaseHubProps {
  entries: StrongEntry[];
  onAddEntry: (entry: StrongEntry) => void;
  onImportJson: (imported: StrongEntry[]) => void;
  onClearDatabase: () => void;
  onResetToDefault: () => void;
}

export default function DatabaseHub({ 
  entries, onAddEntry, onImportJson, onClearDatabase, onResetToDefault 
}: DatabaseHubProps) {
  // Local states
  const [copied, setCopied] = useState(false);
  const [showJsonTree, setShowJsonTree] = useState(false);
  const [activeTab, setActiveTab] = useState<'view' | 'add' | 'import'>('view');
  
  // Custom Entry Form States
  const [strong, setStrong] = useState('');
  const [langue, setLangue] = useState<'hebreu' | 'grec'>('hebreu');
  const [motOriginal, setMotOriginal] = useState('');
  const [translitteration, setTranslitteration] = useState('');
  const [prononciation, setPrononciation] = useState('');
  const [definition, setDefinition] = useState('');
  const [categorie, setCategorie] = useState('');
  const [type, setType] = useState('nom');
  const [occurrences, setOccurrences] = useState(10);
  const [referencesRaw, setReferencesRaw] = useState('');
  const [formError, setFormError] = useState('');
  const [formSuccess, setFormSuccess] = useState(false);

  // Stringified JSON representation of active database
  const jsonString = JSON.stringify(entries, null, 2);

  // Copy helper
  const handleCopy = () => {
    navigator.clipboard.writeText(jsonString);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // Download helper
  const handleDownload = () => {
    const blob = new Blob([jsonString], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `lexique_strong_bible_${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  // Upload JSON helper
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const text = event.target?.result;
        if (typeof text !== 'string') return;
        
        const parsed = JSON.parse(text);
        if (!Array.isArray(parsed)) {
          alert("Erreur de format : Le fichier JSON doit être un tableau d'entrées.");
          return;
        }

        // Validate basic structure of first item
        if (parsed.length > 0) {
          const item = parsed[0];
          if (!item.strong || !item.mot_original || !item.definition) {
            alert("Format non valide : Le JSON doit contenir au moins les champs 'strong', 'mot_original' et 'definition'.");
            return;
          }
        }

        // Re-align IDs to be unique or sequential if missing, and format fields
        const formatted: StrongEntry[] = parsed.map((item, idx) => {
          const num = parseInt(item.strong?.replace(/[^0-9]/g, '')) || idx + 1;
          const isGrec = item.langue === 'grec' || item.strong?.startsWith('G');
          
          return {
            id: item.id || idx + 1,
            strong: item.strong || (isGrec ? `G${num}` : `H${num}`),
            langue: item.langue || (isGrec ? 'grec' : 'hebreu'),
            numero: item.numero || num,
            mot_original: item.mot_original || '',
            translitteration: item.translitteration || '',
            prononciation: item.prononciation || '',
            definition: item.definition || '',
            categorie: item.categorie || 'Général',
            references: Array.isArray(item.references) ? item.references : [item.references || ''],
            type: item.type || 'nom',
            occurrences: Number(item.occurrences) || 1,
            recherche: item.recherche || `${item.strong} ${item.mot_original} ${item.translitteration} ${item.definition}`.toLowerCase(),
            audio: item.audio || `${item.strong || 'X'}.mp3`,
            image: item.image || null
          };
        });

        onImportJson(formatted);
        alert(`Succès ! ${formatted.length} entrées ont été importées et fusionnées avec succès !`);
      } catch (err) {
        alert("Erreur lors de l'analyse du JSON. Veuillez vérifier que le fichier est valide.");
      }
    };
    reader.readAsText(file);
  };

  // Submit custom entry form
  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setFormError('');
    setFormSuccess(false);

    if (!strong.trim()) return setFormError("Le numéro Strong est obligatoire (ex: H3068 ou G2316).");
    if (!motOriginal.trim()) return setFormError("Le mot original est obligatoire (ex: יהוה).");
    if (!translitteration.trim()) return setFormError("La translittération est obligatoire.");
    if (!definition.trim()) return setFormError("La définition est obligatoire.");

    // Validate Strong Format
    const strongFormatted = strong.trim().toUpperCase();
    if (!/^[HG][0-9]+$/.test(strongFormatted)) {
      return setFormError("Le format Strong doit commencer par 'H' pour l'hébreu ou 'G' pour le grec, suivi de chiffres (ex: H3068).");
    }

    const numericPart = parseInt(strongFormatted.substring(1)) || 0;
    const finalLangue = strongFormatted.startsWith('H') ? 'hebreu' : 'grec';

    // Split references by comma
    const refs = referencesRaw
      .split(',')
      .map(r => r.trim())
      .filter(r => r !== '');

    // Form search term index
    const searchIndex = `${strongFormatted} ${motOriginal} ${translitteration} ${prononciation} ${definition} ${categorie} ${type} ${refs.join(' ')}`.toLowerCase();

    // Auto-generate ID (max existing id + 1)
    const nextId = entries.length > 0 ? Math.max(...entries.map(e => e.id)) + 1 : 1;

    const newEntry: StrongEntry = {
      id: nextId,
      strong: strongFormatted,
      langue: finalLangue,
      numero: numericPart,
      mot_original: motOriginal.trim(),
      translitteration: translitteration.trim(),
      prononciation: prononciation.trim() || translitteration.trim(),
      definition: definition.trim(),
      categorie: categorie.trim() || "Général",
      references: refs.length > 0 ? refs : ["Non spécifié"],
      type: type,
      occurrences: Number(occurrences) || 1,
      recherche: searchIndex,
      audio: `${strongFormatted}.mp3`,
      image: null
    };

    onAddEntry(newEntry);
    setFormSuccess(true);
    
    // Clear fields
    setStrong('');
    setMotOriginal('');
    setTranslitteration('');
    setPrononciation('');
    setDefinition('');
    setCategorie('');
    setReferencesRaw('');
  };

  return (
    <div className="space-y-6">
      {/* Overview stats */}
      <div className="bg-white p-6 rounded-3xl border border-gray-100 shadow-sm flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div className="flex items-center gap-3">
          <div className="bg-amber-100 p-2.5 rounded-xl text-amber-700">
            <Database className="h-6 w-6" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-gray-900">Centre de Base de Données</h2>
            <p className="text-xs text-gray-500">
              Gérez, exportez et enrichissez votre dictionnaire contenant actuellement <strong className="font-mono text-gray-800">{entries.length} entrées</strong>.
            </p>
          </div>
        </div>

        {/* Global actions */}
        <div className="flex flex-wrap gap-2 shrink-0">
          <button
            onClick={onResetToDefault}
            className="px-3.5 py-2 bg-gray-50 hover:bg-gray-100 text-gray-600 rounded-xl text-xs font-semibold flex items-center gap-1.5 border border-gray-200 transition-all cursor-pointer"
            title="Réinitialiser la base de données aux 40 mots de base hébreu / grec"
          >
            <RefreshCw className="h-3.5 w-3.5" /> Réinitialiser
          </button>
          <button
            onClick={() => {
              if (confirm("ATTENTION : Êtes-vous sûr de vouloir vider TOUTE la base de données ? Cette action est irréversible.")) {
                onClearDatabase();
              }
            }}
            className="px-3.5 py-2 bg-red-50 hover:bg-red-100 text-red-600 rounded-xl text-xs font-semibold flex items-center gap-1.5 border border-red-100 transition-all cursor-pointer"
          >
            <Trash2 className="h-3.5 w-3.5" /> Tout Vider
          </button>
        </div>
      </div>

      {/* Database tab switcher */}
      <div className="flex bg-gray-100 p-1.5 rounded-2xl max-w-md">
        <button
          onClick={() => { setActiveTab('view'); setFormSuccess(false); }}
          className={`flex-1 py-2.5 text-xs font-bold rounded-xl transition-all cursor-pointer ${
            activeTab === 'view' ? 'bg-white text-gray-900 shadow-xs' : 'text-gray-500 hover:text-gray-800'
          }`}
        >
          Visualiser & Copier
        </button>
        <button
          onClick={() => { setActiveTab('add'); setFormSuccess(false); }}
          className={`flex-1 py-2.5 text-xs font-bold rounded-xl transition-all cursor-pointer ${
            activeTab === 'add' ? 'bg-white text-gray-900 shadow-xs' : 'text-gray-500 hover:text-gray-800'
          }`}
        >
          Ajouter manuellement
        </button>
        <button
          onClick={() => { setActiveTab('import'); setFormSuccess(false); }}
          className={`flex-1 py-2.5 text-xs font-bold rounded-xl transition-all cursor-pointer ${
            activeTab === 'import' ? 'bg-white text-gray-900 shadow-xs' : 'text-gray-500 hover:text-gray-800'
          }`}
        >
          Importer un fichier
        </button>
      </div>

      <AnimatePresence mode="wait">
        {/* TAB 1: VIEW & EXPORT */}
        {activeTab === 'view' && (
          <motion.div
            key="view"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 10 }}
            className="bg-white p-6 rounded-3xl border border-gray-100 shadow-md space-y-4"
          >
            <div className="flex justify-between items-center pb-2 border-b border-gray-50">
              <div>
                <h3 className="text-sm font-bold text-gray-800">Fichier de dictionnaire JSON unique</h3>
                <p className="text-[11px] text-gray-400">Totalement compatible avec Flutter, React, Firebase, PostgreSQL, SQLite...</p>
              </div>
              <div className="flex gap-2">
                <button
                  onClick={handleCopy}
                  className="px-3 py-1.5 bg-gray-100 hover:bg-gray-200 text-gray-700 text-xs font-bold rounded-lg transition-all flex items-center gap-1 cursor-pointer"
                >
                  {copied ? <Check className="h-3.5 w-3.5 text-emerald-600" /> : <Copy className="h-3.5 w-3.5" />}
                  {copied ? 'Copié !' : 'Copier'}
                </button>
                <button
                  onClick={handleDownload}
                  className="px-3 py-1.5 bg-amber-500 hover:bg-amber-600 text-white text-xs font-bold rounded-lg transition-all flex items-center gap-1 cursor-pointer"
                >
                  <Download className="h-3.5 w-3.5" /> Télécharger (.json)
                </button>
              </div>
            </div>

            {/* Tree switch */}
            <div className="flex justify-end">
              <button
                onClick={() => setShowJsonTree(!showJsonTree)}
                className="text-xs font-semibold text-amber-600 hover:text-amber-800 flex items-center gap-1 cursor-pointer"
              >
                <Eye className="h-3.5 w-3.5" /> {showJsonTree ? 'Masquer la prévisualisation' : 'Afficher la prévisualisation brute (JSON)'}
              </button>
            </div>

            {/* Code Box */}
            {showJsonTree ? (
              <div className="relative">
                <pre className="bg-gray-950 text-emerald-400 font-mono text-xs p-5 rounded-2xl overflow-x-auto max-h-[350px] leading-relaxed border border-gray-800">
                  {jsonString}
                </pre>
                <span className="absolute bottom-3 right-3 text-[10px] text-gray-500 font-mono bg-gray-900/80 px-2 py-0.5 rounded">
                  {entries.length} items
                </span>
              </div>
            ) : (
              <div className="bg-amber-50/10 border border-amber-100/50 p-5 rounded-2xl text-xs space-y-3">
                <p className="text-gray-700 leading-relaxed font-medium">
                  💡 <strong>Comment utiliser ce fichier JSON dans vos autres projets de Quiz Bibliques ?</strong>
                </p>
                <ul className="list-disc pl-5 text-gray-600 space-y-2 leading-relaxed">
                  <li><strong>Flutter & React Native :</strong> Placez le fichier téléchargé dans vos assets locaux, chargez-le avec le gestionnaire d'assets de votre application, et lisez-le comme une chaîne de caractères à analyser (JSON Decode).</li>
                  <li><strong>Firebase Firestore :</strong> Vous pouvez écrire un script Node.js simple pour boucler sur ce tableau et appeler `firestore.collection('strongs').add(entry)` pour charger toute la base de données en une seule fois.</li>
                  <li><strong>PostgreSQL / Supabase / SQLite :</strong> Le schéma plat permet une insertion directe ou une création de table :
                    <code className="block bg-gray-50 text-gray-800 font-mono p-2 rounded mt-1 overflow-x-auto border border-gray-100">
                      CREATE TABLE strongs (id INT PRIMARY KEY, strong VARCHAR(10), langue VARCHAR(10), numero INT, mot_original VARCHAR(100), translitteration VARCHAR(150), prononciation VARCHAR(150), definition TEXT, categorie VARCHAR(100), references_text TEXT[], type VARCHAR(50), occurrences INT, recherche TEXT, audio VARCHAR(50), image TEXT);
                    </code>
                  </li>
                </ul>
              </div>
            )}
          </motion.div>
        )}

        {/* TAB 2: MANUAL ADDITION */}
        {activeTab === 'add' && (
          <motion.div
            key="add"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 10 }}
            className="bg-white p-6 rounded-3xl border border-gray-100 shadow-md"
          >
            <h3 className="text-sm font-bold text-gray-800 mb-4 flex items-center gap-1.5">
              <PlusCircle className="h-4.5 w-4.5 text-amber-500" /> Ajouter un mot personnalisé au dictionnaire
            </h3>

            {formError && (
              <div className="bg-red-50 border border-red-100 text-red-700 px-4 py-3 rounded-xl text-xs flex items-center gap-2 mb-4">
                <AlertCircle className="h-4 w-4 shrink-0" /> {formError}
              </div>
            )}

            {formSuccess && (
              <div className="bg-emerald-50 border border-emerald-100 text-emerald-800 px-4 py-3 rounded-xl text-xs flex items-center gap-2 mb-4 font-semibold">
                ✓ Le mot a été ajouté à votre dictionnaire avec succès ! Vous pouvez maintenant le chercher ou le jouer dans le quiz.
              </div>
            )}

            <form onSubmit={handleAddSubmit} className="space-y-4 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {/* Strong number */}
                <div>
                  <label className="block text-gray-500 font-bold mb-1 uppercase font-mono">1. Numéro Strong *</label>
                  <input
                    type="text"
                    placeholder="ex: H3068 ou G2316"
                    value={strong}
                    onChange={(e) => setStrong(e.target.value)}
                    className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3.5 py-2.5 focus:outline-none focus:border-amber-500"
                  />
                  <span className="text-[10px] text-gray-400 mt-1 block">H + chiffres (Hébreu), G + chiffres (Grec)</span>
                </div>

                {/* Mot original */}
                <div>
                  <label className="block text-gray-500 font-bold mb-1 uppercase font-mono">2. Mot original *</label>
                  <input
                    type="text"
                    placeholder="ex: יהוה ou θεός"
                    value={motOriginal}
                    onChange={(e) => setMotOriginal(e.target.value)}
                    className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3.5 py-2.5 text-right font-semibold text-lg focus:outline-none focus:border-amber-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {/* Translitteration */}
                <div>
                  <label className="block text-gray-500 font-bold mb-1 uppercase font-mono">3. Translittération *</label>
                  <input
                    type="text"
                    placeholder="ex: YHWH / Yahweh"
                    value={translitteration}
                    onChange={(e) => setTranslitteration(e.target.value)}
                    className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3.5 py-2.5 focus:outline-none focus:border-amber-500"
                  />
                </div>

                {/* Prononciation */}
                <div>
                  <label className="block text-gray-500 font-bold mb-1 uppercase font-mono">4. Prononciation</label>
                  <input
                    type="text"
                    placeholder="ex: Ya-oué ou Thé-os"
                    value={prononciation}
                    onChange={(e) => setPrononciation(e.target.value)}
                    className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3.5 py-2.5 focus:outline-none focus:border-amber-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                {/* Theme / Category */}
                <div>
                  <label className="block text-gray-500 font-bold mb-1 uppercase font-mono">5. Catégorie / Thème</label>
                  <input
                    type="text"
                    placeholder="ex: Noms de Dieu, Vertus"
                    value={categorie}
                    onChange={(e) => setCategorie(e.target.value)}
                    className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3.5 py-2.5 focus:outline-none focus:border-amber-500"
                  />
                </div>

                {/* Grammatical Type */}
                <div>
                  <label className="block text-gray-500 font-bold mb-1 uppercase font-mono">6. Type Grammatical</label>
                  <select
                    value={type}
                    onChange={(e) => setType(e.target.value)}
                    className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3.5 py-2.5 focus:outline-none focus:border-amber-500"
                  >
                    <option value="nom">Nom</option>
                    <option value="verbe">Verbe</option>
                    <option value="adjectif">Adjectif</option>
                    <option value="adverbe">Adverbe</option>
                    <option value="pronom">Pronom</option>
                    <option value="conjonction">Conjonction</option>
                    <option value="nom propre">Nom Propre</option>
                  </select>
                </div>

                {/* Occurrences */}
                <div>
                  <label className="block text-gray-500 font-bold mb-1 uppercase font-mono">7. Occurrences</label>
                  <input
                    type="number"
                    value={occurrences}
                    onChange={(e) => setOccurrences(Number(e.target.value))}
                    className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3.5 py-2.5 focus:outline-none focus:border-amber-500"
                  />
                </div>
              </div>

              {/* References */}
              <div>
                <label className="block text-gray-500 font-bold mb-1 uppercase font-mono">8. Références clés (séparées par des virgules)</label>
                <input
                  type="text"
                  placeholder="ex: Genèse 2:4, Exode 3:15, Jean 1:1"
                  value={referencesRaw}
                  onChange={(e) => setReferencesRaw(e.target.value)}
                  className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3.5 py-2.5 focus:outline-none focus:border-amber-500"
                />
              </div>

              {/* Definition */}
              <div>
                <label className="block text-gray-500 font-bold mb-1 uppercase font-mono">9. Définition *</label>
                <textarea
                  rows={3}
                  placeholder="Écrivez la définition lexicale complète du mot."
                  value={definition}
                  onChange={(e) => setDefinition(e.target.value)}
                  className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3.5 py-2.5 focus:outline-none focus:border-amber-500"
                />
              </div>

              {/* Submit btn */}
              <div className="flex justify-end pt-2">
                <button
                  type="submit"
                  className="px-6 py-2.5 bg-amber-500 hover:bg-amber-600 text-white font-bold rounded-xl transition-all shadow-md shadow-amber-500/10 cursor-pointer"
                >
                  Ajouter à la base
                </button>
              </div>
            </form>
          </motion.div>
        )}

        {/* TAB 3: FILE IMPORT */}
        {activeTab === 'import' && (
          <motion.div
            key="import"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 10 }}
            className="bg-white p-6 rounded-3xl border border-gray-100 shadow-md space-y-6"
          >
            <div>
              <h3 className="text-sm font-bold text-gray-800">Importer un fichier de dictionnaire JSON</h3>
              <p className="text-xs text-gray-400 mt-1">Vous pouvez charger n'importe quel fichier JSON de dictionnaire respectant la structure attendue pour y jouer avec vos propres données.</p>
            </div>

            {/* Drag & Drop simulated selector */}
            <div className="border-2 border-dashed border-gray-200 rounded-2xl p-8 text-center bg-gray-50 hover:bg-gray-100/50 hover:border-amber-300 transition-all cursor-pointer relative">
              <input
                type="file"
                accept=".json"
                onChange={handleFileUpload}
                className="absolute inset-0 opacity-0 cursor-pointer"
              />
              <Upload className="h-10 w-10 text-gray-400 mx-auto mb-3" />
              <p className="text-xs font-bold text-gray-700">Sélectionner ou glisser un fichier JSON</p>
              <p className="text-[10px] text-gray-400 mt-1.5">Fichiers .json uniquement</p>
            </div>

            {/* Structural reminder */}
            <div className="bg-gray-50 p-4 rounded-xl text-[10px] font-mono space-y-1.5 text-gray-500">
              <div className="font-bold text-gray-600 mb-1">💡 RAPPEL DE LA STRUCTURE ATTENDUE :</div>
              <div>{"["}</div>
              <div className="pl-4">{"{"}</div>
              <div className="pl-8">"strong": "H3068",</div>
              <div className="pl-8">"langue": "hebreu",</div>
              <div className="pl-8">"mot_original": "יהוה",</div>
              <div className="pl-8">"translitteration": "YHWH / Yahweh",</div>
              <div className="pl-8">"prononciation": "Ya-oué",</div>
              <div className="pl-8">"definition": "L'Éternel, le Dieu d'Israël, le nom propre...",</div>
              <div className="pl-8">"categorie": "Noms de Dieu",</div>
              <div className="pl-8">"references": ["Genèse 2:4"]</div>
              <div className="pl-4">{"}"}</div>
              <div>{"]"}</div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
