import React, { useState, useMemo } from 'react';
import { StrongEntry } from '../types';
import { Search, BookOpen, Volume2, Bookmark, Flame, Calendar, Tag, Filter, X } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface DictionaryBrowserProps {
  entries: StrongEntry[];
  onEditEntry?: (entry: StrongEntry) => void;
  onDeleteEntry?: (id: number) => void;
}

export default function DictionaryBrowser({ entries, onEditEntry, onDeleteEntry }: DictionaryBrowserProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [langFilter, setLangFilter] = useState<'all' | 'hebreu' | 'grec'>('all');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedEntry, setSelectedEntry] = useState<StrongEntry | null>(null);

  // Get all unique categories dynamically
  const categories = useMemo(() => {
    const list = new Set<string>();
    entries.forEach(e => {
      if (e.categorie) list.add(e.categorie);
    });
    return ['all', ...Array.from(list)];
  }, [entries]);

  // Filtered entries
  const filteredEntries = useMemo(() => {
    return entries.filter(e => {
      // Language filter
      if (langFilter !== 'all' && e.langue !== langFilter) return false;
      
      // Category filter
      if (selectedCategory !== 'all' && e.categorie !== selectedCategory) return false;
      
      // Search query filter
      if (searchQuery.trim() !== '') {
        const query = searchQuery.toLowerCase();
        return e.recherche.includes(query) || 
               e.strong.toLowerCase().includes(query) ||
               e.mot_original.includes(query) ||
               e.translitteration.toLowerCase().includes(query) ||
               e.definition.toLowerCase().includes(query);
      }
      
      return true;
    });
  }, [entries, langFilter, selectedCategory, searchQuery]);

  return (
    <div className="space-y-6">
      {/* Search and Filter Controls */}
      <div className="bg-white p-5 rounded-2xl border border-gray-100 shadow-sm space-y-4">
        <div className="flex flex-col md:flex-row gap-3">
          {/* Search bar */}
          <div className="relative flex-1">
            <Search className="absolute left-3.5 top-3.5 h-5 w-5 text-gray-400" />
            <input
              type="text"
              placeholder="Rechercher par numéro Strong, mot, translittération, définition..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-11 pr-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500/20 focus:border-amber-500 transition-all text-sm text-gray-800"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-3.5 text-gray-400 hover:text-gray-600"
              >
                <X className="h-4 w-4" />
              </button>
            )}
          </div>

          {/* Language filter buttons */}
          <div className="flex bg-gray-100 p-1 rounded-xl shrink-0">
            <button
              onClick={() => setLangFilter('all')}
              className={`px-4 py-2 text-xs font-semibold rounded-lg transition-all ${
                langFilter === 'all'
                  ? 'bg-white text-gray-900 shadow-sm'
                  : 'text-gray-500 hover:text-gray-800'
              }`}
            >
              Tous ({entries.length})
            </button>
            <button
              onClick={() => setLangFilter('hebreu')}
              className={`px-4 py-2 text-xs font-semibold rounded-lg transition-all ${
                langFilter === 'hebreu'
                  ? 'bg-amber-100 text-amber-900 shadow-xs'
                  : 'text-gray-500 hover:text-gray-800'
              }`}
            >
              Hébreu ({entries.filter(e => e.langue === 'hebreu').length})
            </button>
            <button
              onClick={() => setLangFilter('grec')}
              className={`px-4 py-2 text-xs font-semibold rounded-lg transition-all ${
                langFilter === 'grec'
                  ? 'bg-blue-100 text-blue-900 shadow-xs'
                  : 'text-gray-500 hover:text-gray-800'
              }`}
            >
              Grec ({entries.filter(e => e.langue === 'grec').length})
            </button>
          </div>
        </div>

        {/* Category filtering */}
        <div className="flex flex-wrap items-center gap-2 pt-2 border-t border-gray-50">
          <span className="text-xs font-medium text-gray-500 flex items-center gap-1.5 mr-2">
            <Filter className="h-3.5 w-3.5" /> Thèmes :
          </span>
          <button
            onClick={() => setSelectedCategory('all')}
            className={`px-3 py-1 rounded-full text-xs font-medium transition-all ${
              selectedCategory === 'all'
                ? 'bg-gray-800 text-white'
                : 'bg-gray-50 text-gray-600 hover:bg-gray-100'
            }`}
          >
            Tous les thèmes
          </button>
          {categories.filter(c => c !== 'all').map(cat => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1 rounded-full text-xs font-medium transition-all ${
                selectedCategory === cat
                  ? 'bg-amber-600 text-white shadow-xs'
                  : 'bg-gray-50 text-gray-600 hover:bg-gray-100'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Grid count */}
      <div className="flex justify-between items-center px-1">
        <p className="text-xs text-gray-500 font-mono">
          {filteredEntries.length} mot{filteredEntries.length > 1 ? 's' : ''} trouvé{filteredEntries.length > 1 ? 's' : ''}
        </p>
      </div>

      {/* Grid of cards */}
      {filteredEntries.length === 0 ? (
        <div className="text-center py-16 bg-white rounded-2xl border border-gray-100 shadow-sm">
          <BookOpen className="h-12 w-12 text-gray-300 mx-auto mb-3" />
          <p className="text-gray-500 text-sm">Aucune entrée trouvée avec ces critères.</p>
          <button
            onClick={() => { setSearchQuery(''); setLangFilter('all'); setSelectedCategory('all'); }}
            className="mt-4 px-4 py-2 bg-amber-500 hover:bg-amber-600 text-white text-xs font-semibold rounded-lg transition-all"
          >
            Réinitialiser les filtres
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filteredEntries.map((entry) => (
            <motion.div
              key={entry.id}
              layoutId={`card-${entry.id}`}
              onClick={() => setSelectedEntry(entry)}
              className="bg-white p-5 rounded-2xl border border-gray-100 shadow-xs hover:shadow-md hover:border-amber-200 transition-all cursor-pointer flex flex-col justify-between group"
            >
              <div>
                {/* Header row */}
                <div className="flex justify-between items-start mb-3">
                  <span className={`px-2.5 py-0.5 rounded-md text-[10px] font-bold uppercase tracking-wider font-mono ${
                    entry.langue === 'hebreu' 
                      ? 'bg-amber-50 text-amber-700 border border-amber-200/50' 
                      : 'bg-blue-50 text-blue-700 border border-blue-200/50'
                  }`}>
                    {entry.strong}
                  </span>
                  <span className="text-[10px] font-medium text-gray-400 bg-gray-50 px-2 py-0.5 rounded-md">
                    {entry.categorie}
                  </span>
                </div>

                {/* Words */}
                <div className="flex items-baseline gap-3 mb-2">
                  <h3 className={`text-2xl font-bold ${
                    entry.langue === 'hebreu' ? 'font-serif text-right text-amber-950' : 'font-sans text-blue-950'
                  }`}>
                    {entry.mot_original}
                  </h3>
                  <div className="text-xs text-gray-500 italic">
                    {entry.translitteration} ({entry.prononciation})
                  </div>
                </div>

                {/* Definition snippet */}
                <p className="text-sm text-gray-600 line-clamp-2 mt-1 leading-relaxed">
                  {entry.definition}
                </p>
              </div>

              {/* Bottom stats row */}
              <div className="flex justify-between items-center mt-4 pt-3 border-t border-gray-50 text-[11px] text-gray-400 font-mono">
                <span className="capitalize">{entry.type}</span>
                <span className="flex items-center gap-1">
                  <Flame className="h-3 w-3 text-orange-400" /> {entry.occurrences} occurrences
                </span>
              </div>
            </motion.div>
          ))}
        </div>
      )}

      {/* Entry Detail Modal */}
      <AnimatePresence>
        {selectedEntry && (
          <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 z-50">
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 15 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 15 }}
              transition={{ type: 'spring', damping: 25, stiffness: 350 }}
              className="bg-white rounded-3xl w-full max-w-xl overflow-hidden shadow-2xl border border-gray-100 flex flex-col max-h-[90vh]"
            >
              {/* Colorful Top Banner depending on language */}
              <div className={`p-6 text-white flex justify-between items-start ${
                selectedEntry.langue === 'hebreu'
                  ? 'bg-gradient-to-r from-amber-700 via-amber-800 to-amber-900'
                  : 'bg-gradient-to-r from-blue-700 via-blue-800 to-blue-900'
              }`}>
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="bg-white/20 text-white text-xs px-2.5 py-0.5 rounded-md font-mono font-bold tracking-wider">
                      {selectedEntry.strong}
                    </span>
                    <span className="text-xs uppercase font-bold tracking-wider opacity-90">
                      Lexique {selectedEntry.langue}
                    </span>
                  </div>
                  <h2 className={`text-4xl font-black mt-2 tracking-wide ${
                    selectedEntry.langue === 'hebreu' ? 'font-serif' : 'font-sans'
                  }`}>
                    {selectedEntry.mot_original}
                  </h2>
                </div>
                <button
                  onClick={() => setSelectedEntry(null)}
                  className="p-1.5 rounded-full bg-white/10 hover:bg-white/20 text-white transition-all cursor-pointer"
                >
                  <X className="h-5 w-5" />
                </button>
              </div>

              {/* Modal Body */}
              <div className="p-6 overflow-y-auto space-y-6 flex-1">
                {/* Transliteration & Pronunciation */}
                <div className="grid grid-cols-2 gap-4 bg-gray-50 p-4 rounded-2xl">
                  <div>
                    <span className="text-[10px] font-mono text-gray-400 uppercase block mb-1">Translittération</span>
                    <span className="text-sm font-semibold text-gray-800">{selectedEntry.translitteration}</span>
                  </div>
                  <div>
                    <span className="text-[10px] font-mono text-gray-400 uppercase block mb-1">Prononciation</span>
                    <span className="text-sm font-semibold text-gray-800 flex items-center gap-1.5">
                      {selectedEntry.prononciation}
                      <Volume2 className="h-4 w-4 text-amber-500 animate-pulse" />
                    </span>
                  </div>
                </div>

                {/* Definition */}
                <div>
                  <h4 className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-2 flex items-center gap-1.5 font-mono">
                    <BookOpen className="h-3.5 w-3.5 text-amber-500" /> Définition Lexicale
                  </h4>
                  <p className="text-gray-700 leading-relaxed bg-amber-50/20 border border-amber-100/50 p-4 rounded-2xl text-sm">
                    {selectedEntry.definition}
                  </p>
                </div>

                {/* Category & Grammatical details */}
                <div className="grid grid-cols-2 gap-4">
                  <div className="border border-gray-100 p-3.5 rounded-2xl">
                    <span className="text-[10px] font-mono text-gray-400 uppercase block mb-1">Thématique</span>
                    <span className="text-xs font-semibold text-gray-700 bg-gray-100 px-2 py-1 rounded-md inline-block">
                      {selectedEntry.categorie}
                    </span>
                  </div>
                  <div className="border border-gray-100 p-3.5 rounded-2xl">
                    <span className="text-[10px] font-mono text-gray-400 uppercase block mb-1">Type Grammatical</span>
                    <span className="text-xs font-semibold text-gray-700 capitalize">
                      {selectedEntry.type}
                    </span>
                  </div>
                </div>

                {/* Occurrences & References */}
                <div className="space-y-4">
                  <div className="flex justify-between items-center border-b border-gray-100 pb-3">
                    <span className="text-xs font-bold text-gray-400 uppercase font-mono flex items-center gap-1.5">
                      <Flame className="h-3.5 w-3.5 text-orange-500" /> Occurrences Bibliques
                    </span>
                    <span className="text-sm font-black text-gray-800 font-mono bg-orange-50 text-orange-700 px-3 py-1 rounded-lg">
                      {selectedEntry.occurrences} fois
                    </span>
                  </div>

                  <div>
                    <span className="text-xs font-bold text-gray-400 uppercase font-mono block mb-2 flex items-center gap-1.5">
                      <Tag className="h-3.5 w-3.5 text-blue-500" /> Références clés
                    </span>
                    <div className="flex flex-wrap gap-2">
                      {selectedEntry.references.map((ref, idx) => (
                        <span
                          key={idx}
                          className="bg-blue-50/80 hover:bg-blue-100 text-blue-700 border border-blue-100 px-3 py-1.5 rounded-xl text-xs font-semibold font-mono transition-all"
                        >
                          {ref}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Technical metadata */}
                <div className="pt-4 border-t border-gray-100 flex items-center justify-between text-[10px] text-gray-400 font-mono">
                  <span>Fichier Audio : {selectedEntry.audio}</span>
                  {onDeleteEntry && (
                    <div className="flex gap-2">
                      {onEditEntry && (
                        <button
                          onClick={() => {
                            onEditEntry(selectedEntry);
                            setSelectedEntry(null);
                          }}
                          className="text-amber-600 hover:text-amber-800 font-bold hover:underline"
                        >
                          Modifier
                        </button>
                      )}
                      <button
                        onClick={() => {
                          if (confirm(`Êtes-vous sûr de vouloir supprimer l'entrée ${selectedEntry.strong} ?`)) {
                            onDeleteEntry(selectedEntry.id);
                            setSelectedEntry(null);
                          }
                        }}
                        className="text-red-500 hover:text-red-700 font-bold hover:underline"
                      >
                        Supprimer
                      </button>
                    </div>
                  )}
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
