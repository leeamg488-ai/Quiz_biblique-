import React, { useState } from 'react';
import { StrongEntry } from '../types';
import { Sparkles, ArrowRight, Loader2, Play, Plus, BookOpen, HelpCircle } from 'lucide-react';
import { motion } from 'motion/react';

interface AIParserProps {
  entriesCount: number;
  onMergeEntries: (newEntries: StrongEntry[]) => void;
}

export default function AIParser({ entriesCount, onMergeEntries }: AIParserProps) {
  const [rawText, setRawText] = useState('');
  const [loading, setLoading] = useState(false);
  const [loadingStep, setLoadingStep] = useState(0);
  const [parsedResults, setParsedResults] = useState<StrongEntry[] | null>(null);
  const [error, setError] = useState('');

  // Reassuring loading steps
  const loadingSteps = [
    "Initialisation de l'analyse linguistique...",
    "Extraction des caractères hébreux/grecs et des translittérations...",
    "Génération des indices phonétiques et de la prononciation...",
    "Structuration des définitions et des catégories théologiques...",
    "Extraction et mise en forme des références bibliques...",
    "Validation et compilation du JSON final..."
  ];

  // Rotate loading steps during conversion
  React.useEffect(() => {
    let interval: NodeJS.Timeout;
    if (loading) {
      interval = setInterval(() => {
        setLoadingStep(prev => (prev + 1) % loadingSteps.length);
      }, 2500);
    } else {
      setLoadingStep(0);
    }
    return () => clearInterval(interval);
  }, [loading]);

  // Raw text examples for quick trial
  const examples = [
    {
      title: "Hébreu (Yahweh & Elohim bruts)",
      text: "H3068 - YHWH - Ya-oué - L'Eternel, le nom sacré de Dieu - Genèse 2:4 - 6828 occurrences\nH430 - Elohim - Dieu Créateur - Genèse 1:1"
    },
    {
      title: "Grec (Christos & Logos bruts)",
      text: "G5547 Christos, l'Oint, le Messie consacré par Dieu. Equivalent de Mashiach - Matthieu 1:1 - 529 occurrences\nG3056 Logos, Parole, Verbe, expression de Dieu - Jean 1:1 - 330 occurrences"
    }
  ];

  const handleParse = async () => {
    if (!rawText.trim()) {
      setError("Veuillez saisir ou coller du texte brut à convertir.");
      return;
    }

    setLoading(true);
    setError('');
    setParsedResults(null);

    try {
      const response = await fetch('/api/parse-strong', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          rawText,
          startId: entriesCount + 101 // Safe starting index
        })
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || data.details || "Erreur inconnue lors du traitement.");
      }

      if (Array.isArray(data)) {
        setParsedResults(data);
      } else {
        throw new Error("Le serveur n'a pas renvoyé un tableau valide.");
      }
    } catch (err: any) {
      console.error(err);
      setError(err.message || "Une erreur est survenue lors de la connexion au serveur.");
    } finally {
      setLoading(false);
    }
  };

  const handleMerge = () => {
    if (parsedResults && parsedResults.length > 0) {
      onMergeEntries(parsedResults);
      alert(`Succès ! ${parsedResults.length} nouveaux mots ont été intégrés à votre dictionnaire actif.`);
      setParsedResults(null);
      setRawText('');
    }
  };

  return (
    <div className="space-y-6">
      {/* Introduction Card */}
      <div className="bg-gradient-to-r from-amber-500 to-amber-600 p-6 md:p-8 rounded-3xl text-white shadow-md relative overflow-hidden">
        <div className="relative z-10 space-y-2">
          <div className="inline-flex bg-white/20 px-3 py-1 rounded-full text-xs font-bold tracking-wider uppercase">
            Propulsé par Gemini 3.5 Flash
          </div>
          <h2 className="text-xl md:text-2xl font-black">Convertisseur Intelligent de Lexique</h2>
          <p className="text-xs md:text-sm text-amber-50 leading-relaxed max-w-xl">
            Collez n'importe quel texte ou liste brute d'un dictionnaire Strong. Notre IA va automatiquement détecter les mots, extraire l'hébreu/grec, générer la translittération, la prononciation, le thème et structurer le tout en un JSON propre, prêt pour le quiz !
          </p>
        </div>
        <Sparkles className="absolute right-6 bottom-6 h-28 w-28 text-white/10 pointer-events-none" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column: Input and Examples */}
        <div className="lg:col-span-2 space-y-4">
          <div className="bg-white p-5 rounded-2xl border border-gray-100 shadow-sm space-y-4">
            <div className="flex justify-between items-center">
              <label className="text-xs font-bold text-gray-400 uppercase tracking-wider font-mono">
                Texte brut à parser
              </label>
              {rawText && (
                <button
                  onClick={() => setRawText('')}
                  className="text-xs font-semibold text-gray-400 hover:text-gray-600"
                >
                  Effacer
                </button>
              )}
            </div>

            <textarea
              rows={10}
              placeholder="Exemple : 
H3068 - Yahweh - L'Éternel, le nom propre et sacré de Dieu - Genèse 2:4
G2316 - theos - Dieu, l'Etre suprême - Jean 1:1"
              value={rawText}
              onChange={(e) => setRawText(e.target.value)}
              className="w-full bg-gray-50 border border-gray-200 rounded-xl p-4 text-xs font-mono focus:outline-none focus:ring-2 focus:ring-amber-500/20 focus:border-amber-500 transition-all leading-relaxed"
              disabled={loading}
            />

            {error && (
              <div className="bg-red-50 border border-red-100 text-red-700 p-4 rounded-xl text-xs space-y-1">
                <p className="font-bold">Conversion impossible :</p>
                <p className="leading-relaxed">{error}</p>
                <p className="text-[10px] text-red-500 pt-1">
                  💡 Assurez-vous d'avoir configuré votre clé API Gemini dans <strong>Settings &gt; Secrets</strong> si ce n'est pas encore fait.
                </p>
              </div>
            )}

            <div className="flex justify-end">
              <button
                onClick={handleParse}
                disabled={loading || !rawText.trim()}
                className="px-6 py-3.5 bg-gray-800 hover:bg-gray-950 disabled:bg-gray-200 disabled:text-gray-400 text-white font-black rounded-xl shadow-md transition-all cursor-pointer flex items-center gap-2 text-xs"
              >
                {loading ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin" /> Analyse IA en cours...
                  </>
                ) : (
                  <>
                    <Play className="h-4 w-4 fill-white" /> Structurer le texte avec l'IA
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Quick Examples */}
          <div className="space-y-2">
            <span className="text-[11px] font-bold text-gray-400 uppercase tracking-wider font-mono">Exemples d'essais rapides</span>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {examples.map((ex, i) => (
                <button
                  key={i}
                  onClick={() => setRawText(ex.text)}
                  className="bg-white p-4 rounded-xl border border-gray-100 shadow-xs hover:border-amber-200 text-left transition-all cursor-pointer space-y-1 group"
                  disabled={loading}
                >
                  <h4 className="text-xs font-bold text-gray-800 flex items-center justify-between">
                    {ex.title}
                    <ArrowRight className="h-3 w-3 text-gray-300 group-hover:text-amber-500 transition-all" />
                  </h4>
                  <p className="text-[10px] text-gray-400 line-clamp-2 font-mono">
                    {ex.text}
                  </p>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Right Column: Loading or Results */}
        <div className="space-y-4">
          <div className="bg-white p-5 rounded-2xl border border-gray-100 shadow-sm min-h-[300px] flex flex-col justify-between">
            {/* 1. Initial Empty state */}
            {!loading && !parsedResults && (
              <div className="flex-1 flex flex-col items-center justify-center text-center p-6 space-y-3">
                <HelpCircle className="h-10 w-10 text-gray-300" />
                <h4 className="text-xs font-bold text-gray-700">Aucun résultat à afficher</h4>
                <p className="text-[11px] text-gray-400 leading-relaxed">
                  Saisissez du texte à gauche et lancez l'analyse par l'IA. Les résultats structurés s'afficheront ici en temps réel.
                </p>
              </div>
            )}

            {/* 2. Loading state */}
            {loading && (
              <div className="flex-1 flex flex-col items-center justify-center text-center p-6 space-y-4">
                <Loader2 className="h-8 w-8 text-amber-500 animate-spin" />
                <div className="space-y-1">
                  <h4 className="text-xs font-bold text-gray-800">Génération par l'IA...</h4>
                  <p className="text-[10px] text-gray-400 italic leading-relaxed min-h-[40px] px-2 animate-pulse">
                    "{loadingSteps[loadingStep]}"
                  </p>
                </div>
                <div className="w-2/3 bg-gray-100 h-1 rounded-full overflow-hidden">
                  <div className="bg-amber-500 h-full w-1/2 animate-shimmer" />
                </div>
              </div>
            )}

            {/* 3. Success parsing results */}
            {parsedResults && (
              <div className="flex-1 flex flex-col justify-between h-full space-y-4">
                <div className="space-y-3">
                  <div className="flex items-center gap-2 text-emerald-600 font-bold text-xs">
                    <BookOpen className="h-4.5 w-4.5" /> {parsedResults.length} mot{parsedResults.length > 1 ? 's' : ''} structuré{parsedResults.length > 1 ? 's' : ''} !
                  </div>

                  {/* List of converted words */}
                  <div className="space-y-2 max-h-[220px] overflow-y-auto pr-1">
                    {parsedResults.map((item, index) => (
                      <div key={index} className="p-2.5 bg-gray-50 rounded-lg border border-gray-100 flex justify-between items-center text-[10px]">
                        <div>
                          <div className="flex items-center gap-1.5">
                            <span className="font-mono font-bold text-gray-500 bg-gray-200/50 px-1 rounded">{item.strong}</span>
                            <span className="font-bold text-gray-800">{item.translitteration}</span>
                          </div>
                          <p className="text-gray-400 line-clamp-1 mt-0.5">{item.definition}</p>
                        </div>
                        <span className="font-bold text-xs font-serif shrink-0 text-gray-700 bg-white px-2 py-0.5 rounded border border-gray-100">
                          {item.mot_original}
                        </span>
                      </div>
                    ))}
                  </div>

                  <p className="text-[10px] text-gray-400 leading-relaxed">
                    Vérifiez la liste ci-dessus. Si tout vous convient, fusionnez ces données avec votre dictionnaire local pour pouvoir immédiatement jouer au quiz avec.
                  </p>
                </div>

                {/* Merge trigger */}
                <button
                  onClick={handleMerge}
                  className="w-full py-3 bg-emerald-500 hover:bg-emerald-600 text-white font-bold rounded-xl text-xs transition-all shadow-md shadow-emerald-500/15 flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Plus className="h-4 w-4" /> Fusionner avec le dictionnaire ({entriesCount} → {entriesCount + parsedResults.length})
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
