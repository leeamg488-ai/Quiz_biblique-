import React, { useState, useEffect, useMemo } from 'react';
import { StrongEntry } from '../types';
import { motion, AnimatePresence } from 'motion/react';
import { Award, RefreshCw, CheckCircle2, XCircle, ArrowRight, BookOpen, Flame, HelpCircle, Shuffle } from 'lucide-react';

interface QuizGameProps {
  entries: StrongEntry[];
}

interface Question {
  correctEntry: StrongEntry;
  choices: {
    entry: StrongEntry;
    text: string; // The text to display (either definition or the formatted Strong string)
  }[];
}

export default function QuizGame({ entries }: QuizGameProps) {
  // Game states
  const [gameStarted, setGameStarted] = useState(false);
  const [quizMode, setQuizMode] = useState<1 | 2>(1);
  const [langFilter, setLangFilter] = useState<'all' | 'hebreu' | 'grec'>('all');
  const [score, setScore] = useState(0);
  const [questionCount, setQuestionCount] = useState(0);
  const [totalQuestions, setTotalQuestions] = useState(10); // Default to 10 questions
  const [currentQuestion, setCurrentQuestion] = useState<Question | null>(null);
  const [selectedAnswerIdx, setSelectedAnswerIdx] = useState<number | null>(null);
  const [isAnswered, setIsAnswered] = useState(false);
  const [streak, setStreak] = useState(0);
  const [bestStreak, setBestStreak] = useState(0);
  const [quizFinished, setQuizFinished] = useState(false);

  // Filter entries available for the quiz
  const availableEntries = useMemo(() => {
    return entries.filter(e => {
      if (langFilter === 'all') return true;
      return e.langue === langFilter;
    });
  }, [entries, langFilter]);

  // Helper to shuffle array
  const shuffleArray = <T,>(array: T[]): T[] => {
    return [...array].sort(() => Math.random() - 0.5);
  };

  // Generate a new question
  const generateQuestion = (): Question | null => {
    if (availableEntries.length < 4) {
      return null;
    }

    // Pick a random correct entry
    const correctEntry = availableEntries[Math.floor(Math.random() * availableEntries.length)];

    // Pick 3 random distinct incorrect entries
    const incorrectCandidates = entries.filter(e => e.strong !== correctEntry.strong);
    const shuffledIncorrect = shuffleArray(incorrectCandidates);
    const incorrectEntries = shuffledIncorrect.slice(0, 3);

    // Form choices
    const allChoices = [correctEntry, ...incorrectEntries].map(entry => {
      let text = '';
      if (quizMode === 1) {
        text = entry.definition;
      } else {
        // Mode 2 format: "H3068 — יהוה — YHWH / Yahweh"
        text = `${entry.strong} — ${entry.mot_original} — ${entry.translitteration}`;
      }
      return { entry, text };
    });

    return {
      correctEntry,
      choices: shuffleArray(allChoices)
    };
  };

  // Start the game
  const startGame = (mode: 1 | 2, lang: 'all' | 'hebreu' | 'grec', limit: number) => {
    setQuizMode(mode);
    setLangFilter(lang);
    setTotalQuestions(limit);
    setScore(0);
    setQuestionCount(0);
    setStreak(0);
    setQuizFinished(false);
    setGameStarted(true);
    setIsAnswered(false);
    setSelectedAnswerIdx(null);
  };

  // Setup the first question when game starts
  useEffect(() => {
    if (gameStarted && !quizFinished && questionCount === 0) {
      const q = generateQuestion();
      if (q) {
        setCurrentQuestion(q);
        setQuestionCount(1);
      } else {
        alert("Pas assez d'entrées disponibles pour ce filtre. Ajoutez plus de mots d'abord !");
        setGameStarted(false);
      }
    }
  }, [gameStarted, availableEntries, quizMode]);

  // Handle option selection
  const handleAnswerSelect = (index: number) => {
    if (isAnswered) return;

    setSelectedAnswerIdx(index);
    setIsAnswered(true);

    const chosenEntry = currentQuestion?.choices[index].entry;
    const isCorrect = chosenEntry?.strong === currentQuestion?.correctEntry.strong;

    if (isCorrect) {
      setScore(prev => prev + 1);
      setStreak(prev => {
        const newStreak = prev + 1;
        if (newStreak > bestStreak) setBestStreak(newStreak);
        return newStreak;
      });
    } else {
      setStreak(0);
    }
  };

  // Advance to next question
  const handleNextQuestion = () => {
    if (questionCount >= totalQuestions) {
      setQuizFinished(true);
    } else {
      const q = generateQuestion();
      if (q) {
        setCurrentQuestion(q);
        setQuestionCount(prev => prev + 1);
        setIsAnswered(false);
        setSelectedAnswerIdx(null);
      }
    }
  };

  // Return to settings
  const resetGame = () => {
    setGameStarted(false);
    setQuizFinished(false);
    setCurrentQuestion(null);
    setQuestionCount(0);
  };

  if (entries.length < 4) {
    return (
      <div className="bg-amber-50 border border-amber-200 rounded-3xl p-8 text-center max-w-xl mx-auto space-y-4">
        <HelpCircle className="h-14 w-14 text-amber-500 mx-auto" />
        <h3 className="text-lg font-bold text-amber-900">Quiz Indisponible</h3>
        <p className="text-amber-700 text-sm leading-relaxed">
          Le quiz nécessite un dictionnaire d'au moins <strong>4 entrées</strong> pour générer des propositions à choix multiples. 
          Actuellement, vous n'avez que {entries.length} mot{entries.length > 1 ? 's' : ''} dans votre dictionnaire.
        </p>
        <p className="text-xs text-amber-600">
          Veuillez importer ou ajouter de nouvelles entrées dans l'onglet dictionnaire ou via le convertisseur IA.
        </p>
      </div>
    );
  }

  // --- RENDER GAME OVER / FINISHED ---
  if (quizFinished) {
    const successRate = Math.round((score / totalQuestions) * 100);
    return (
      <motion.div
        initial={{ opacity: 0, y: 15 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-white rounded-3xl p-8 border border-gray-100 shadow-lg text-center max-w-lg mx-auto space-y-6"
      >
        <div className="inline-flex bg-amber-50 p-4 rounded-full">
          <Award className="h-16 w-16 text-amber-500" />
        </div>

        <div className="space-y-2">
          <h2 className="text-2xl font-black text-gray-900">Quiz Terminé !</h2>
          <p className="text-gray-500 text-sm">
            Mode {quizMode === 1 ? 'Strong → Définition' : 'Définition → Strong'} ({langFilter === 'hebreu' ? 'Hébreu' : langFilter === 'grec' ? 'Grec' : 'Mélangé'})
          </p>
        </div>

        {/* Score Ring */}
        <div className="py-4">
          <div className="inline-block relative">
            <div className="text-4xl font-extrabold text-amber-600 font-mono">
              {score} / {totalQuestions}
            </div>
            <div className="text-[11px] font-bold text-gray-400 uppercase tracking-widest mt-1">
              Score ({successRate}%)
            </div>
          </div>
        </div>

        {/* Stats Row */}
        <div className="grid grid-cols-2 gap-4 bg-gray-50 p-4 rounded-2xl">
          <div>
            <span className="text-[10px] font-mono text-gray-400 uppercase block mb-1">Meilleure Série</span>
            <span className="text-lg font-bold text-gray-800 flex items-center justify-center gap-1.5 font-mono">
              <Flame className="h-4.5 w-4.5 text-orange-500" /> {bestStreak}
            </span>
          </div>
          <div>
            <span className="text-[10px] font-mono text-gray-400 uppercase block mb-1">Précision</span>
            <span className="text-lg font-bold text-gray-800">
              {successRate >= 80 ? '👑 Excellent' : successRate >= 50 ? '👍 Bon travail' : '📖 À réviser'}
            </span>
          </div>
        </div>

        {/* Buttons */}
        <div className="flex flex-col sm:flex-row gap-3 pt-4">
          <button
            onClick={() => startGame(quizMode, langFilter, totalQuestions)}
            className="flex-1 py-3.5 px-4 bg-gray-800 hover:bg-gray-950 text-white font-bold rounded-xl transition-all cursor-pointer text-sm shadow-sm flex items-center justify-center gap-2"
          >
            <RefreshCw className="h-4 w-4" /> Rejouer ce mode
          </button>
          <button
            onClick={resetGame}
            className="flex-1 py-3.5 px-4 bg-amber-500 hover:bg-amber-600 text-white font-bold rounded-xl transition-all cursor-pointer text-sm shadow-sm flex items-center justify-center gap-2"
          >
            Changer de mode
          </button>
        </div>
      </motion.div>
    );
  }

  // --- RENDER GAME SETTINGS ---
  if (!gameStarted) {
    return (
      <div className="bg-white rounded-3xl p-6 md:p-8 border border-gray-100 shadow-md max-w-2xl mx-auto">
        <div className="flex items-center gap-3 mb-6">
          <div className="bg-amber-100 p-2.5 rounded-xl text-amber-700">
            <Shuffle className="h-6 w-6" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-gray-900">Quiz Lexique Strong</h2>
            <p className="text-xs text-gray-500">Testez vos connaissances en hébreu et grec biblique avec des questions générées dynamiquement.</p>
          </div>
        </div>

        <div className="space-y-6">
          {/* Mode Selection */}
          <div className="space-y-3">
            <label className="text-xs font-bold text-gray-400 uppercase tracking-wider font-mono">1. Sélectionner le Mode de Jeu</label>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <button
                onClick={() => setQuizMode(1)}
                className={`p-5 rounded-2xl border text-left transition-all cursor-pointer flex flex-col justify-between ${
                  quizMode === 1
                    ? 'border-amber-500 bg-amber-50/30 ring-2 ring-amber-500/15'
                    : 'border-gray-100 hover:border-gray-200 hover:bg-gray-50/50'
                }`}
              >
                <div>
                  <span className="text-xs font-bold text-amber-600 font-mono block mb-1">MODE 1</span>
                  <h4 className="text-sm font-bold text-gray-800">Strong → Définition</h4>
                  <p className="text-xs text-gray-500 mt-2 leading-relaxed">
                    L'application affiche le mot original, sa translittération et sa prononciation. Vous devez trouver la bonne définition parmi 4 propositions.
                  </p>
                </div>
                <span className="text-[10px] text-gray-400 mt-4 block">Ex: H3068 יהוה → Trouver la définition</span>
              </button>

              <button
                onClick={() => setQuizMode(2)}
                className={`p-5 rounded-2xl border text-left transition-all cursor-pointer flex flex-col justify-between ${
                  quizMode === 2
                    ? 'border-amber-500 bg-amber-50/30 ring-2 ring-amber-500/15'
                    : 'border-gray-100 hover:border-gray-200 hover:bg-gray-50/50'
                }`}
              >
                <div>
                  <span className="text-xs font-bold text-amber-600 font-mono block mb-1">MODE 2</span>
                  <h4 className="text-sm font-bold text-gray-800">Définition → Strong</h4>
                  <p className="text-xs text-gray-500 mt-2 leading-relaxed">
                    L'application affiche une définition. Vous devez identifier le bon mot Strong sous la forme <code className="bg-gray-100 px-1 py-0.5 rounded text-[10px] font-mono">ID — Mot — Translittération</code>.
                  </p>
                </div>
                <span className="text-[10px] text-gray-400 mt-4 block">Ex: L'Éternel... → Trouver YHWH (H3068)</span>
              </button>
            </div>
          </div>

          {/* Filters Row */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Lang filter */}
            <div className="space-y-2">
              <label className="text-xs font-bold text-gray-400 uppercase tracking-wider font-mono">2. Langue de l'étude</label>
              <div className="flex bg-gray-100 p-1 rounded-xl">
                <button
                  onClick={() => setLangFilter('all')}
                  className={`flex-1 py-2 text-xs font-semibold rounded-lg transition-all ${
                    langFilter === 'all' ? 'bg-white text-gray-900 shadow-xs' : 'text-gray-500 hover:text-gray-800'
                  }`}
                >
                  Mélangé
                </button>
                <button
                  onClick={() => setLangFilter('hebreu')}
                  className={`flex-1 py-2 text-xs font-semibold rounded-lg transition-all ${
                    langFilter === 'hebreu' ? 'bg-amber-100 text-amber-900 shadow-xs' : 'text-gray-500 hover:text-gray-800'
                  }`}
                >
                  Hébreu uniquement
                </button>
                <button
                  onClick={() => setLangFilter('grec')}
                  className={`flex-1 py-2 text-xs font-semibold rounded-lg transition-all ${
                    langFilter === 'grec' ? 'bg-blue-100 text-blue-900 shadow-xs' : 'text-gray-500 hover:text-gray-800'
                  }`}
                >
                  Grec uniquement
                </button>
              </div>
            </div>

            {/* Questions count */}
            <div className="space-y-2">
              <label className="text-xs font-bold text-gray-400 uppercase tracking-wider font-mono">3. Nombre de questions</label>
              <div className="flex bg-gray-100 p-1 rounded-xl">
                {[5, 10, 20].map((num) => (
                  <button
                    key={num}
                    onClick={() => setTotalQuestions(num)}
                    className={`flex-1 py-2 text-xs font-semibold rounded-lg font-mono transition-all ${
                      totalQuestions === num ? 'bg-white text-gray-900 shadow-xs' : 'text-gray-500 hover:text-gray-800'
                    }`}
                  >
                    {num} Q
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Action Trigger */}
          <div className="pt-4 border-t border-gray-50 flex items-center justify-between">
            <span className="text-xs text-gray-400 font-mono">
              Dictionnaire actif : {entries.length} mots disponibles
            </span>
            <button
              onClick={() => startGame(quizMode, langFilter, totalQuestions)}
              className="px-6 py-3 bg-amber-500 hover:bg-amber-600 text-white font-bold rounded-xl shadow-md shadow-amber-500/10 hover:shadow-lg transition-all cursor-pointer flex items-center gap-2 text-sm"
            >
              Lancer le Quiz <ArrowRight className="h-4 w-4" />
            </button>
          </div>
        </div>
      </div>
    );
  }

  // --- RENDER ACTIVE GAMEPLAY ---
  if (!currentQuestion) return null;

  const isCurrentCorrectIdx = (index: number) => {
    return currentQuestion.choices[index].entry.strong === currentQuestion.correctEntry.strong;
  };

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      {/* HUD Header */}
      <div className="bg-white p-4 rounded-2xl border border-gray-100 shadow-xs flex justify-between items-center">
        <div className="space-y-1">
          <span className="text-[10px] font-mono text-gray-400 uppercase tracking-wider">Progression</span>
          <p className="text-sm font-bold text-gray-800 font-mono">
            Question {questionCount} / {totalQuestions}
          </p>
        </div>

        {/* Streak & Score pill */}
        <div className="flex items-center gap-3">
          {streak > 0 && (
            <motion.div
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="bg-orange-50 text-orange-700 px-3 py-1.5 rounded-xl text-xs font-bold font-mono flex items-center gap-1 border border-orange-100"
            >
              <Flame className="h-4 w-4 text-orange-500 fill-orange-500" /> Streak : {streak}
            </motion.div>
          )}

          <div className="bg-amber-50 text-amber-700 px-3.5 py-1.5 rounded-xl text-xs font-bold font-mono border border-amber-100">
            Score : {score}
          </div>
        </div>
      </div>

      {/* Progress Bar */}
      <div className="w-full bg-gray-100 h-1.5 rounded-full overflow-hidden">
        <motion.div
          initial={{ width: 0 }}
          animate={{ width: `${(questionCount / totalQuestions) * 100}%` }}
          className="bg-amber-500 h-full"
        />
      </div>

      {/* Question Card */}
      <div className="bg-white p-6 md:p-8 rounded-3xl border border-gray-100 shadow-md space-y-6">
        <div className="text-center space-y-3">
          <span className={`px-2.5 py-0.5 rounded-md text-[10px] font-bold tracking-wider uppercase font-mono ${
            currentQuestion.correctEntry.langue === 'hebreu' ? 'bg-amber-100 text-amber-800' : 'bg-blue-100 text-blue-800'
          }`}>
            Lexique {currentQuestion.correctEntry.langue} ({currentQuestion.correctEntry.strong})
          </span>

          {quizMode === 1 ? (
            // Mode 1: Display Word -> Ask definition
            <div className="space-y-2 py-4">
              <h1 className={`text-4xl md:text-5xl font-black ${
                currentQuestion.correctEntry.langue === 'hebreu' ? 'font-serif text-amber-950' : 'font-sans text-blue-950'
              }`}>
                {currentQuestion.correctEntry.mot_original}
              </h1>
              <p className="text-gray-500 text-sm italic font-medium">
                {currentQuestion.correctEntry.translitteration} • Prononcé : "{currentQuestion.correctEntry.prononciation}"
              </p>
              <div className="h-4" />
              <h3 className="text-sm font-semibold text-gray-700">Quelle est la bonne définition ?</h3>
            </div>
          ) : (
            // Mode 2: Display definition -> Ask word
            <div className="space-y-4 py-4 px-3 bg-amber-50/15 border border-amber-100/40 rounded-2xl">
              <h3 className="text-xs font-bold text-gray-400 uppercase tracking-widest font-mono">DÉFINITION</h3>
              <p className="text-base md:text-lg text-gray-800 leading-relaxed font-semibold">
                "{currentQuestion.correctEntry.definition}"
              </p>
              <div className="h-2" />
              <h3 className="text-sm font-semibold text-gray-700">Quel est ce mot Strong ?</h3>
            </div>
          )}
        </div>

        {/* Choices List */}
        <div className="grid grid-cols-1 gap-3">
          {currentQuestion.choices.map((choice, idx) => {
            let btnClass = "border-gray-100 hover:border-amber-300 hover:bg-gray-50/40 text-gray-700";
            let iconElement = null;

            if (isAnswered) {
              const isCorrectChoice = isCurrentCorrectIdx(idx);
              const isSelectedChoice = selectedAnswerIdx === idx;

              if (isCorrectChoice) {
                btnClass = "border-emerald-500 bg-emerald-50/40 text-emerald-900 font-semibold ring-2 ring-emerald-500/10";
                iconElement = <CheckCircle2 className="h-5 w-5 text-emerald-600 shrink-0" />;
              } else if (isSelectedChoice) {
                btnClass = "border-rose-500 bg-rose-50/30 text-rose-950 ring-2 ring-rose-500/10";
                iconElement = <XCircle className="h-5 w-5 text-rose-500 shrink-0" />;
              } else {
                btnClass = "border-gray-100 bg-gray-50/50 text-gray-400 opacity-60";
              }
            }

            return (
              <button
                key={idx}
                disabled={isAnswered}
                onClick={() => handleAnswerSelect(idx)}
                className={`p-4 rounded-2xl border text-left text-sm transition-all flex items-center justify-between gap-3 ${
                  !isAnswered ? 'cursor-pointer active:scale-[0.99]' : 'cursor-default'
                } ${btnClass}`}
              >
                <div className="flex items-center gap-3">
                  <span className={`w-6 h-6 rounded-lg text-xs font-bold flex items-center justify-center border font-mono ${
                    isAnswered ? 'bg-gray-100/50 text-gray-400 border-gray-200' : 'bg-gray-50 text-gray-500 border-gray-100'
                  }`}>
                    {String.fromCharCode(65 + idx)}
                  </span>
                  <span className="leading-relaxed">{choice.text}</span>
                </div>
                {iconElement}
              </button>
            );
          })}
        </div>

        {/* Answer feedback and Next button */}
        <AnimatePresence>
          {isAnswered && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="pt-4 border-t border-gray-100 space-y-4"
            >
              {/* Detailed Explanation */}
              <div className="bg-amber-50/40 border border-amber-100 p-4 rounded-2xl text-xs space-y-2">
                <div className="flex items-center gap-1 text-amber-800 font-bold">
                  <BookOpen className="h-4 w-4 shrink-0 text-amber-600" /> Fiche d'étude : {currentQuestion.correctEntry.strong}
                </div>
                <p className="text-gray-700 leading-relaxed">
                  <strong>{currentQuestion.correctEntry.mot_original} ({currentQuestion.correctEntry.translitteration})</strong> : {currentQuestion.correctEntry.definition}
                </p>
                <div className="flex flex-wrap gap-2 pt-1">
                  <span className="bg-gray-100 text-gray-600 px-2 py-0.5 rounded font-mono">
                    Catégorie : {currentQuestion.correctEntry.categorie}
                  </span>
                  <span className="bg-gray-100 text-gray-600 px-2 py-0.5 rounded font-mono">
                    Occurrences : {currentQuestion.correctEntry.occurrences} fois
                  </span>
                  {currentQuestion.correctEntry.references.map((ref, i) => (
                    <span key={i} className="bg-blue-50 text-blue-700 px-2 py-0.5 rounded font-mono">
                      {ref}
                    </span>
                  ))}
                </div>
              </div>

              {/* Action Button */}
              <div className="flex justify-end gap-3">
                <button
                  onClick={resetGame}
                  className="px-4 py-2 text-xs font-semibold text-gray-500 hover:text-gray-800 transition-all cursor-pointer"
                >
                  Quitter le quiz
                </button>
                <button
                  onClick={handleNextQuestion}
                  className="px-6 py-3 bg-gray-800 hover:bg-gray-950 text-white text-xs font-bold rounded-xl shadow-md transition-all cursor-pointer flex items-center gap-2"
                >
                  {questionCount >= totalQuestions ? 'Voir les résultats' : 'Question suivante'} <ArrowRight className="h-4 w-4" />
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
