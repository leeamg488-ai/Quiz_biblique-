export interface StrongEntry {
  id: number;
  strong: string; // e.g. "H3068"
  langue: 'hebreu' | 'grec';
  numero: number; // e.g. 3068
  mot_original: string; // e.g. "יהוה"
  translitteration: string; // e.g. "YHWH / Yahweh"
  prononciation: string; // e.g. "Ya-oué"
  definition: string; // e.g. "L'Éternel, le Dieu d'Israël, le nom propre..."
  categorie: string; // e.g. "Noms de Dieu"
  references: string[]; // e.g. ["Genèse 2:4"]
  type: string; // e.g. "nom", "verbe", "adjectif"
  occurrences: number;
  recherche: string; // lowercased terms for quick client-side search
  audio: string; // e.g. "H3068.mp3"
  image: string | null;
}
